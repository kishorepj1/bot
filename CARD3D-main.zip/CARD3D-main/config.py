
import os
from dotenv import load_dotenv

load_dotenv()

# --------------------- Configuration ---------------------

API_ID = 24509589
API_HASH = "717cf21d94c4934bcbe1eaa1ad86ae75"
STRING = "BQF1_JUAr-uINLoTLpqX3qXm2ITVK-zOdsY2LVNPbEpNsV5zb1lMg80l1aV4-1HQc0gsJAXhOQjijnJdK__oSIZjZkhjGVb92dUubd_OamvQv84AxLSltMpd2LabeHCahTbvo4SO48syVXYKJc9vqy-7d4zaP1E8o370S4ffhRQZJt_GzIH9Lq6rg4sZDm-_FHo9R_9wEU6khPJe7a2l53cmHPta6rLji86KZ8R9qaUlNQjUg911bUwudxYZMQM9fN70luZxi911rHlAdVxBQfp8HWY4wLNF29br_-uH4BEsN3Dj82Zrtixk3eDRQCleLuJXhA_7grMvkekHWOA0-whlzCgvkwAAAAHNyayXAA"
BOT_TOKEN = "7670251631:AAF75r7Ep5uToIcozGIuwxO0AdripbNgdwc"
OWNER_ID = 7716352578
MONGO_URL = "mongodb+srv://git:git@git.scvzxhw.mongodb.net"
DEEP_API = "88052311-be39-4e2d-9f37-b4d18597c8c5"
LOGGER_ID = -1001887976586
SUPPORT_CHAT_LINK = os.getenv("SUPPORT_CHAT_LINK", "https://t.me/+DRJZZnF2ptlmZmY1")
GPT_API = "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"

# ----------------------------------------------------------
