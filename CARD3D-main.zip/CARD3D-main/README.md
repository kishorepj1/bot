<h2 align="center">
    ─「 🦋ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ💗 」─
</h2>
<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>
<br>
<p align="center"><a href="http://dashboard.heroku.com/new?template=https://github.com/daxxteam/CARD3D"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-pink?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
</details>

```I'm Getting Off so no more on that project

Available on 21 June 2025
