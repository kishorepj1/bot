import asyncio
import importlib
from pyrogram import idle
from CARD3D import app, userbot
from CARD3D.modules import ALL_MODULES
import config

LOGGER_ID = config.LOGGER_ID

async def ava_boot():
    try:

        for module in ALL_MODULES:
            try:
                importlib.import_module(f"CARD3D.modules.{module}")
            except Exception as module_error:
                print(f"Error importing module '{module}': {module_error}")
                raise module_error  

        print("» ʙᴏᴛ ᴅᴇᴘʟᴏʏᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅")
    except Exception as e:
        print(f"Critical error during module import: {e}")
        return

    try:

        await app.send_message(
            LOGGER_ID, 
            "**ɪ ᴀᴍ ᴀʟɪᴠᴇ ʙᴀʙʏ ʏᴏᴜʀ ʙᴏᴛ ᴅᴇᴘʟᴏʏᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅ \n"
            "ᴍʏ ᴅᴇᴠᴇʟᴏᴘᴇʀ [Daxx](https://t.me/STRIPEHIT)**"
        )
        await userbot.send_message(
            LOGGER_ID, 
            "**ɪ ᴀᴍ ᴀʟɪᴠᴇ ʙᴀʙʏ ʏᴏᴜʀ ʙᴏᴛ ᴅᴇᴘʟᴏʏᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ ✅**"
        )
    except Exception as e:
        print(f"Error sending messages: {e}")
        return

    await idle()
    print("» ɢᴏᴏᴅ ʙʏᴇ sᴛᴏᴘᴘɪɴɢ ʙᴏᴛ.")

if __name__ == "__main__":
    try:

        loop = asyncio.get_event_loop()
        loop.run_until_complete(ava_boot())
    except Exception as main_error:
        print(f"Error in main bot loop: {main_error}")
