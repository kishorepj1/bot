import re
import asyncio
import time
from pyrogram import filters
from pyrogram.enums import ParseMode
from pyrogram.types import Message
from os import remove as osremove
from urllib.parse import urlparse
from CARD3D import app, userbot
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from config import OWNER_ID

PLAN_LIMITS = {
    "Free": 3000,
    "Bronze": 5000,
    "Silver": 8000,
    "Gold": 15000,
    "Platinum": 25000,
    "Diamond": 50000,
    "STRIPEHIT": 10000000,
}

def extract_cc_details(text):
    pattern = r'\d{15,16}\D*\d{2}\D*\d{2,4}\D*\d{3,4}'
    cc_details = re.findall(pattern, text)
    valid_cc = []
    for cc in cc_details:
        exv = re.findall(r'\d+', cc)
        if len(exv) == 4:
            card_number, mo, year, cvv = exv
            year = year[-2:]
            valid_cc.append(f"{card_number}|{mo}|{year}|{cvv}")
    return valid_cc

async def join_channel_with_approval(userbot, channel_url):
    while True:
        try:
            return await userbot.join_chat(channel_url)
        except Exception as e:
            error_message = str(e)
            if 'This is a private channel and you need to join it first' in error_message:
                await asyncio.sleep(5)
            elif 'The invite link is invalid or has expired' in error_message:
                raise ValueError("Invalid or expired invite link.")
            elif 'USER_ALREADY_PARTICIPANT' in error_message:
                return await userbot.get_chat(channel_url)
            else:
                raise e

async def animate_processing(message):
    animation_frames = ['■□□□', '■■□□', '■■■□', '■■■■']
    processing_msg = await message.reply("Processing your request\nPlease wait")
    try:
        while True:
            for frame in animation_frames:
                await processing_msg.edit_text(f"Processing your request\nPlease wait {frame}")
                await asyncio.sleep(3.5)
    except asyncio.CancelledError:
        await processing_msg.delete()

@app.on_message(filters.command("scr", prefixes=[".", "/"]))
async def scr_oni(_, message: Message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=1)

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_credits = -1
    else:
        user = await get_user(user_id)
        if not user:
            await message.reply_text("❌ **You are not registered. Please register using  /register in private.**")
            return
        user_plan = user.get("plan", "Free")
        user_credits = user.get("credits", 0)

    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')
    plan_limit = PLAN_LIMITS.get(user_plan, 3000)

    if not has_access:
        await message.reply_text(access_msg)
        return

    args = message.text.split(' ')[1:]
    if len(args) < 2:
        resp = """
**Wrong Format ❌**

**Usage:**
**For Public Group/Channel Scraping**
`/scr [username] [Amount]`

**For Private Group/Channel Scraping**
`/scr [link] [Amount]`

**For specific BIN**
`/scr [username] OR [link] [Amount] [BIN]`
        """
        await message.reply_text(resp)
        return

    channel_url = args[0]
    limit = int(args[1]) if args[1].isdigit() else 100
    bin = args[2] if len(args) > 2 else None

    if limit > plan_limit:
        await message.reply_text(
            f"⚠️ **Your plan ({user_plan}) has a scraping limit of {plan_limit} cards.**\n"
            "**Upgrade your plan to scrape more data.**",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True
        )
        return

    parsed_url = urlparse(channel_url)
    if parsed_url.scheme and parsed_url.netloc and parsed_url.path.startswith('/+'):
        try:
            chat_info = await join_channel_with_approval(userbot, channel_url)
            channel_id = chat_info.id
        except Exception as e:
            await message.reply(f"Error joining channel: {str(e)}")
            return
    else:
        channel_id = parsed_url.path.lstrip('/') if parsed_url.scheme else channel_url

    processing_task = asyncio.create_task(animate_processing(message))

    tic = time.time()

    try:
        mainsc = await scrape(userbot, channel_id, limit, bin)
    except Exception as e:
        processing_task.cancel()
        await message.reply(f"Error scraping: {str(e)}")
        return

    toc = time.time()
    processing_task.cancel()

    if mainsc:
        unique_cc, duplicates_removed = rmv(mainsc)
        if unique_cc:
            file_name = f"CARD3D_X_{channel_id}_X_{len(unique_cc)}_cc.txt"
            with open(file_name, 'w', encoding='utf-8') as f:
                f.write("\n".join(unique_cc))

            with open(file_name, 'rb') as f:
                caption = (
                    f"**𝗖𝗖 𝗦𝗰𝗿𝗮𝗽𝗽𝗲𝗱 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 ✅**\n\n"
                    f"❁ **Amount** ➜ `{len(unique_cc)}`\n"
                    f"❁ **Duplicate** ➜ `{duplicates_removed}`\n"
                    f"❁ **Source** ➜ {channel_id}\n"
                    f"❁ **Time Taken** ➜ {toc - tic:.2f} seconds\n\n"
                    f"❁ **Scraped By** ➜ [{message.from_user.first_name}](tg://user?id={message.from_user.id}) ⤿ {user_plan} {user_plan_symbol} ⤾"
                )
                await app.send_document(message.chat.id, f, caption=caption)
            osremove(file_name)
        else:
            await message.reply("No credit card details found.")
    else:
        await message.reply("No credit card details found.")

    if user_id != OWNER_ID:
        new_credits = user_credits - 1
        await update_user(user_id, {"credits": new_credits})

async def scrape(userbot, channel_id, limit, bin=None):
    cmb = []
    tasks = []

    async for message in userbot.get_chat_history(channel_id, limit=limit):
        ccr = message.text if message.text else message.caption
        if ccr:
            tasks.append(asyncio.create_task(extract_cc_from_message(ccr, bin)))

    if tasks:
        results = await asyncio.gather(*tasks)
        for result in results:
            if result:
                cmb.extend(result)

    return cmb

async def extract_cc_from_message(text, bin):
    valid_cc = extract_cc_details(text)
    if bin:
        valid_cc = [cc for cc in valid_cc if cc.startswith(bin)]
    return valid_cc

def rmv(cc_list):
    unique_cc = list(set(cc_list))
    duplicates_removed = len(cc_list) - len(unique_cc)
    return unique_cc, duplicates_removed
