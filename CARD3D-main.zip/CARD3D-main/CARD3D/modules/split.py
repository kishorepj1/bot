from pyrogram import Client, filters
from pyrogram.types import Message
import os
from CARD3D import app
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from config import OWNER_ID

@app.on_message(filters.command("split") & filters.reply)
async def split_file(client: Client, message: Message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(
        user_id, chat_id, required_credits=0
    )
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please register using  /register in private.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if not message.reply_to_message or not message.reply_to_message.document:
        await message.reply("**Please reply to a document file to split it `/split [number of cc]`**")
        return

    file_id = message.reply_to_message.document.file_id
    file_name = message.reply_to_message.document.file_name
    file_size = message.reply_to_message.document.file_size

    max_file_size = 20 * 1024 * 1024
    if file_size > max_file_size:
        await message.reply(f"❌ The file size is too large ({file_size / (1024 * 1024):.2f} MB). Maximum allowed size is 20 MB.")
        return

    try:
        num_lines = int(message.text.split(" ")[1])
    except (IndexError, ValueError):
        num_lines = 2

    file_path = await client.download_media(file_id)
    if not file_path or not os.path.exists(file_path):
        await message.reply("Failed to download the file.")
        return

    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
    except Exception as e:
        await message.reply(f"Failed to read the file: {str(e)}")
        return

    for i in range(0, len(lines), num_lines):
        split_lines = lines[i:i + num_lines]
        split_file_path = f"split_{i // num_lines + 1}.txt"

        try:
            with open(split_file_path, 'w') as split_file:
                split_file.writelines(split_lines)
            
            await client.send_document(chat_id=message.chat.id, document=split_file_path)
        
        except Exception as e:
            await message.reply(f"Failed to handle the split file: {str(e)}")
        
        finally:
            if os.path.exists(split_file_path):
                os.remove(split_file_path)

    os.remove(file_path)
