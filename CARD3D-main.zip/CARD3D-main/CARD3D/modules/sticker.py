from pyrogram import Client, filters
from PIL import Image
import io
from CARD3D import app

@app.on_message(filters.command("stdl") & filters.reply)
async def download_sticker(client, message):
    if message.reply_to_message.sticker:
        sticker = message.reply_to_message.sticker

        # Download the sticker
        file_path = await client.download_media(sticker.file_id)

        # Open the downloaded WebP file
        with Image.open(file_path) as img:
            png_io = io.BytesIO()
            jpg_io = io.BytesIO()

            # Convert to PNG
            img.save(png_io, format="PNG")
            png_io.seek(0)

            # Convert to JPG
            img.convert("RGB").save(jpg_io, format="JPEG")
            jpg_io.seek(0)

            # Send PNG as document
            await message.reply_document(png_io, file_name="sticker.png")

            # Send JPG as document
            await message.reply_document(jpg_io, file_name="sticker.jpg")
    else:
        await message.reply("Please reply to a sticker message.")
