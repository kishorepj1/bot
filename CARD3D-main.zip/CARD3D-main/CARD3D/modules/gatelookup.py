
import asyncio
import aiohttp
from io import BytesIO
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from pyrogram import filters
from pyrogram.enums import ParseMode
from CARD3D import app
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, LEVELS
import validators

user_agent = UserAgent().random
HEADERS = {'User-Agent': user_agent}
TIMEOUT = 10
MAX_URLS = 500
FILE_THRESHOLD = 20  

def find_captcha(html_content):
    html_content_lower = html_content.lower()
    if any(keyword in html_content_lower for keyword in ['recaptcha', "i'm not a robot", 'protected by recaptcha']):
        return 'Using Google reCAPTCHA ✅'
    if 'hcaptcha' in html_content_lower:
        return 'Using hCaptcha ✅'
    return 'No CAPTCHA 🔥'

def detect_cloudflare(headers, html_content):
    cloudflare_headers = ['Server', 'CF-RAY', 'CF-Cache-Status', 'CF-Request-ID']
    if any(header in headers and 'cloudflare' in headers[header].lower() for header in cloudflare_headers):
        return True
    if any(keyword in html_content.lower() for keyword in ['cloudflare', 'cdnjs.cloudflare.com', 'challenges.cloudflare.com']):
        return True
    return False

def find_payment_gateways(response_text):
    gateways = {
        "paypal": "PayPal", "stripe": "Stripe", "braintree": "Braintree", "square": "Square", 
        "authorize.net": "Authorize.Net", "2checkout": "2Checkout", "adyen": "Adyen", "worldpay": "WorldPay",
        "sagepay": "SagePay", "checkout.com": "Checkout.com", "skrill": "Skrill", "neteller": "Neteller", 
        "payoneer": "Payoneer", "klarna": "Klarna", "afterpay": "Afterpay", "sezzle": "Sezzle", "alipay": "Alipay",
        "wechat pay": "WeChat Pay", "tenpay": "Tenpay", "qpay": "QPay", "sofort": "SOFORT Banking", "giropay": "Giropay",
        "trustly": "Trustly", "zelle": "Zelle", "venmo": "Venmo", "epayments": "ePayments", "revolut": "Revolut",
        "wise": "Wise", "shopify payments": "Shopify Payments", "woocommerce": "WooCommerce Payments", 
        "paytm": "Paytm", "phonepe": "PhonePe", "google pay": "Google Pay", "bhim upi": "BHIM UPI", 
        "razorpay": "Razorpay", "instamojo": "Instamojo", "ccavenue": "CCAvenue", "payu": "PayU", 
        "mobikwik": "MobiKwik", "freecharge": "FreeCharge", "cashfree": "Cashfree", "jio money": "JioMoney", 
        "yandex.money": "Yandex.Money", "qiwi": "QIWI", "webmoney": "WebMoney", "paysafe": "Paysafe", 
        "bpay": "BPAY", "mollie": "Mollie", "paysera": "Paysera", "multibanco": "Multibanco", "pagseguro": "PagSeguro",
        "mercadopago": "MercadoPago", "payfast": "PayFast", "billdesk": "BillDesk", "paystack": "Paystack", 
        "interswitch": "Interswitch", "voguepay": "VoguePay", "flutterwave": "Flutterwave", "propay": "ProPay", 
        "fattura24": "Fattura24", "xoom": "Xoom", "facebook pay": "Facebook Pay", "bokun": "Bokun", 
        "pay2go": "Pay2Go", "paymate": "PayMate", "securionpay": "SecurionPay", "paycentral": "PayCentral", 
        "payment express": "Payment Express", "verified by visa": "Verified by Visa", "pagar.me": "Pagar.me",
        "paylane": "PayLane", "netspend": "NetSpend", "paxum": "Paxum", "bitpay": "BitPay", "payouts": "Payouts",
        "wirecard": "Wirecard", "paysend": "PaySend", "merchant warrior": "Merchant Warrior", "currencyfair": "CurrencyFair", 
        "cpay": "CPay", "xendit": "Xendit", "apple pay": "Apple Pay", "google wallet": "Google Wallet", "cash app": "Cash App", 
        "payforit": "PayForIt", "bill.com": "Bill.com", "eway": "Eway", "pagofacil": "PagoFacil", "boleto bancario": "Boleto Bancario",
        "telebirr": "TeleBirr", "goatpay": "GoatPay", "bancontact": "Bancontact", "ideal": "iDEAL", "eps": "EPS", 
        "blik": "BLIK", "pix": "PIX", "paytm wallet": "Paytm Wallet", "skrill quick checkout": "Skrill Quick Checkout", 
        "fortumo": "Fortumo", "boleto": "Boleto", "paysafecard": "Paysafecard", "worldline": "Worldline", 
        "surepay": "SurePay", "remita": "Remita", "paymaya": "PayMaya", "razorpay flex": "Razorpay Flex", 
        "streamline": "Streamline", "envia": "Envia", "paysera account": "Paysera Account", "acept": "Acept", 
        "korapay": "KoraPay", "paymongo": "PayMongo", "ipay": "iPay", "paysera transfer": "Paysera Transfer", 
        "mollie checkout": "Mollie Checkout", "glopalpay": "GlopalPay", "mcdpay": "MCDPay", "dlocal": "Dlocal", 
        "advcash": "AdvCash", "payza express": "Payza Express", "bluepay": "BluePay", "firstdata": "FirstData", 
        "globalpay": "GlobalPay", "lazerpay": "LazerPay", "mercurepay": "MercurePay", "nuvei": "Nuvei", 
        "omnipay": "Omnipay", "paypal express": "PayPal Express", "payu latam": "PayU Latam", "solidgate": "SolidGate", 
        "stripe billing": "Stripe Billing", "tokenpay": "TokenPay", "wirex": "Wirex", "yoomoney": "YooMoney", 
        "zapper": "Zapper", "zibpay": "ZibPay", "bitso": "Bitso", "currencycloud": "CurrencyCloud", "payone": "Payone", 
        "celerpay": "CelerPay", "moneris": "Moneris", "slydepay": "SlydePay", "billplz": "Billplz", "yoozpay": "YoozPay", 
        "paymentsense": "PaymentSense", "bluehost payments": "Bluehost Payments", "paystack africa": "Paystack Africa", 
        "epayco": "Epayco", "yapay": "Yapay", "mercury pay": "Mercury Pay", "robo pay": "RoboPay", "mercadopago argentina": "MercadoPago Argentina",
        "amex pay": "Amex Pay", "banwire": "Banwire", "atom payment": "Atom Payment", "bambora": "Bambora", 
        "cardsave": "CardSave", "checkout fintech": "Checkout Fintech", "conekta": "Conekta", "dashpay": "DashPay", 
        "easypaisa": "Easypaisa", "fastpay": "FastPay", "gocardless": "GoCardless", "hyperpay": "HyperPay", 
        "instapay": "InstaPay", "klarna pay later": "Klarna Pay Later", "migs": "MIGS", "payline": "Payline", 
        "paystack nigeria": "Paystack Nigeria", "paypal pro": "PayPal Pro", "paytrail": "Paytrail", "stripe connect": "Stripe Connect", 
        "verifone": "Verifone", "wirecard germany": "Wirecard Germany", "worldpay uk": "WorldPay UK"
    }
    return list(set(value for key, value in gateways.items() if key.lower() in response_text.lower())) or ["Unknown"]

def detect_graphql(response_text):
    return '/graphql' in response_text.lower() or 'graphql' in response_text.lower()

def detect_platform(response_text):
    soup = BeautifulSoup(response_text, 'html.parser')
    meta_generator = soup.find('meta', attrs={'name': 'generator'})
    platforms = {
        'woocommerce': 'WooCommerce', 'wordpress': 'WordPress', 'shopify': 'Shopify', 'magento': 'Magento',
        'drupal': 'Drupal', 'joomla': 'Joomla', 'prestashop': 'PrestaShop', 'opencart': 'OpenCart',
        'bigcommerce': 'BigCommerce', 'wix': 'Wix', 'squarespace': 'Squarespace', 'weebly': 'Weebly',
        'sitecore': 'Sitecore', 'umbraco': 'Umbraco', 'demandware': 'Demandware', 'oscommerce': 'osCommerce',
        'lightspeed': 'Lightspeed', 'ecwid': 'Ecwid', 'volusion': 'Volusion', 'nopcommerce': 'nopCommerce',
        'salesforce commerce cloud': 'Salesforce Commerce Cloud', 'oracle commerce': 'Oracle Commerce',
        'hybris': 'Hybris', 'episerver': 'Episerver', 'virtuemart': 'VirtueMart', 'x-cart': 'X-Cart',
        '3dcart': '3dcart', 'aspdotnetstorefront': 'AspDotNetStorefront', 'zencart': 'Zen Cart', 'big cartel': 'Big Cartel',
        'xpressengine': 'XpressEngine', 'shopware': 'Shopware', 'springer commerce': 'Springer Commerce',
        'sailthru': 'SailThru', 'opencollective': 'OpenCollective', 'ghost': 'Ghost', 'medium': 'Medium',
        'tilda': 'Tilda', 'godaddy websites': 'GoDaddy Websites', 'squarespace commerce': 'Squarespace Commerce',
        'kibo commerce': 'Kibo Commerce', 'volusion commerce': 'Volusion Commerce', 'weebly ecommerce': 'Weebly Ecommerce',
        'drupal commerce': 'Drupal Commerce', 'woocommerce bookings': 'WooCommerce Bookings', 'webflow': 'Webflow',
        'cube cart': 'CubeCart', 'elastic path': 'Elastic Path', 'sylius': 'Sylius', 'shopify plus': 'Shopify Plus',
        'lightning shop': 'Lightning Shop', 'magento commerce': 'Magento Commerce', 'salesforce digital commerce': 'Salesforce Digital Commerce',
        'woocommerce subscriptions': 'WooCommerce Subscriptions', 'shopify basic': 'Shopify Basic', 'shopware 6': 'Shopware 6',
        'storefront': 'Storefront', 'magento 2': 'Magento 2', 'square online': 'Square Online', 'weebly pro': 'Weebly Pro',
        'woocommerce storefront': 'WooCommerce Storefront', 'shopify lite': 'Shopify Lite', 'magento open source': 'Magento Open Source',
        'shopify advanced': 'Shopify Advanced', 'shopify enterprise': 'Shopify Enterprise'
    }
    if meta_generator:
        generator_content = meta_generator.get('content', '').lower()
        for key, value in platforms.items():
            if key in generator_content:
                return value
    return next((value for key, value in platforms.items() if key in response_text.lower()), "None")

def detect_error_logs(response_text):
    return "Found" if any(pattern in response_text.lower() for pattern in ['fatal error', 'uncaught exception', 'stack trace', 'call stack', 'notice: undefined', 'warning: include', 'warning: require', 'parse error', 'exception', 'traceback']) else "None"

def detect_3d_secure(response_text):
    return "3D Payment ✅" if any(keyword in response_text.lower() for keyword in [
        '3d secure', 'verified by visa', 'mastercard securecode']) else "2D Payment 🔥"

async def fetch_url(session, url):
    try:
        async with session.get(url, headers=HEADERS, timeout=TIMEOUT) as response:
            return {'status_code': response.status, 'response_text': await response.text(), 'headers': dict(response.headers)}
    except Exception as e:
        print(f"Error fetching URL {url}: {e}")
        return None

async def analyze_url(url):
    try:
        async with aiohttp.ClientSession() as session:
            response_data = await fetch_url(session, url)
            if not response_data:
                return f"Error: Unable to fetch the URL: {url}"
            response_text = response_data['response_text']
            headers = response_data['headers']
            status_code = response_data['status_code']
            detected_gateways = find_payment_gateways(response_text)
            detected_captcha = find_captcha(response_text)
            is_cloudflare_protected = detect_cloudflare(headers, response_text)
            is_graphql_used = detect_graphql(response_text)
            platform = detect_platform(response_text)
            error_logs = detect_error_logs(response_text)
            payment_type = detect_3d_secure(response_text)
            return (f"┏━━━━━━━⍟\n┃ 𝗟𝗼𝗼𝗸𝘂𝗽 𝗥𝗲𝘀𝘂𝗹𝘁 : ✅\n┗━━━━━━━━━━━━⊛\n"
                    f"▰▰▰▰▰▰▰▰▰▰▰▰▰\n\n"
                    f"➥ 𝗦𝗶𝘁𝗲 -» `{url}`\n"
                    f"➥ 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗚𝗮𝘁𝗲𝘄𝗮𝘆𝘀 -» {', '.join(detected_gateways)}\n"
                    f"➥ 𝗖𝗮𝗽𝘁𝗰𝗵𝗮 -» {detected_captcha}\n"
                    f"➥ 𝗖𝗹𝗼𝘂𝗱𝗳𝗹𝗮𝗿𝗲 -» {'True ✅' if is_cloudflare_protected else 'False 🔥'}\n"
                    f"➥ 𝗚𝗿𝗮𝗽𝗵𝗾𝗹 -» {'True ✅' if is_graphql_used else 'False 🔥'}\n"
                    f"➥ 𝗣𝗹𝗮𝘁𝗳𝗼𝗿𝗺 -» {platform}\n"
                    f"➥ 𝗘𝗿𝗿𝗼𝗿 𝗹𝗼𝗴𝘀 -» {error_logs}\n"
                    f"➥ 𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗧𝘆𝗽𝗲 -» {payment_type}\n"
                    f"➥ 𝗦𝘁𝗮𝘁𝘂𝘀 -» {status_code}\n\n"
                    f"▰▰▰▰▰▰▰▰▰▰▰▰▰\n")
    except Exception as e:
        return f"Error processing URL {url}: {e}"

@app.on_message(filters.command("gate"))
async def handle_check_payment_gateways(_, message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return
    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please use /register first.**", parse_mode=ParseMode.MARKDOWN)
        return
    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")
    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    try:
        processing_message = await message.reply("**Processing your request...**", disable_web_page_preview=True)
        
        text_after_command = message.text[len('/gate'):].strip()
        lines = text_after_command.split('\n')
        urls = [line.strip() for line in lines if line.strip()]

        for i in range(len(urls)):
            if not urls[i].startswith(("http://", "https://")):
                urls[i] = "http://" + urls[i]

            if not validators.url(urls[i]):
                await processing_message.edit_text(f"**Error: Invalid URL format - {urls[i]}**", disable_web_page_preview=True)
                return
        
        if not urls:
            await processing_message.edit_text("**Error: No URLs provided.**", disable_web_page_preview=True)
            return
        
        if len(urls) > MAX_URLS:
            await processing_message.edit_text(f"**Error: Too many URLs provided. Maximum limit is {MAX_URLS}.**", disable_web_page_preview=True)
            return
        
        tasks = [analyze_url(url) for url in urls]
        responses = await asyncio.gather(*tasks, return_exceptions=True)

        if len(urls) > FILE_THRESHOLD:
            combined_results = ''
            for i, response in enumerate(responses):
                if isinstance(response, Exception):
                    combined_results += f"URL {i+1}: Error processing URL: {response}\n"
                else:
                    combined_results += response + '\n'
            file = BytesIO(combined_results.encode('utf-8'))
            file.name = 'results.txt'
            try:
                await message.reply_document(file, caption="**Here are your results:**")
                await processing_message.delete()
            except Exception as e:
                await processing_message.edit_text(f"**Error: {e}**", disable_web_page_preview=True)
        else:
            await processing_message.delete()
            for response in responses:
                result_message = response if not isinstance(response, Exception) else f"Error processing URL: {response}"
                try:
                    await message.reply_text(result_message, disable_web_page_preview=True)
                except Exception as e:
                    await message.reply_text(f"**Error: {e}**", disable_web_page_preview=True)
    except Exception as e:
        try:
            await processing_message.edit_text(f"**Error: {e}**", disable_web_page_preview=True)
        except:
            await message.reply_text(f"**Error: {e}**", disable_web_page_preview=True)
