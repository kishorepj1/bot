from CARD3D import app
import os
import asyncio
import aiohttp
from pyrogram import filters
import random
import re
from config import OWNER_ID
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS

IPINFO_TOKEN = 'de9e66ca96b47e'
IPQUALITYSCORE_API_KEY = '6m0y2APPxSNGct3IRUfTx2GHolNGbASE'

async def animate_processing(message, total_ips, progress):
    animation_frames = ['■□□□', '■■□□', '■■■□', '■■■■']
    processing_msg = await message.reply("Processing your request\nPlease wait")
    
    try:
        while not progress['done']:
            for frame in animation_frames:
                if progress['done']:
                    break
                await processing_msg.edit_text(
                    f"Checking {total_ips} IP addresses\n"
                    f"Checked: {progress['count']}/{total_ips} {frame}"
                )
                await asyncio.sleep(3.5)

        await processing_msg.delete()
    except asyncio.CancelledError:
        await processing_msg.delete()

@app.on_message(filters.command(["chkip"]))
async def check_ips_handler(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if len(message.command) == 2 and is_valid_ip(message.command[1]):
        ip_address = message.command[1]
        ip_list = [ip_address]
    elif message.reply_to_message:
        if message.reply_to_message.document:
            file_path = await message.reply_to_message.download()
            ip_list = extract_ips_from_file(file_path)
            os.remove(file_path)
        else:
            ip_text = message.reply_to_message.text
            ip_list = extract_ips(ip_text)
    else:
        await message.reply_text("Please reply to a message containing IP addresses or a document to check, or provide an IP address directly.")
        return

    if not ip_list:
        await message.reply_text("No valid IP addresses found.")
        return

    progress = {'count': 0, 'done': False}

    processing_task = asyncio.create_task(animate_processing(message, len(ip_list), progress))
    checked_ips = await check_ips_and_generate_results(ip_list, progress)
    await processing_task

    if len(ip_list) == 1:
        await message.reply_text(checked_ips[0])
    else:
        file_path = save_checked_ips(checked_ips)
        try:
            await message.reply_document(file_path)

            if user_id != OWNER_ID:
                new_credits = user_credits - 1
            await update_user(user_id, {"credits": new_credits}) 

        except Exception as e:
            print(f"Error sending document: {e}")
        os.remove(file_path)

async def check_ips_and_generate_results(ip_list, progress):
    checked_ips = []
    async with aiohttp.ClientSession() as session:
        for ip in ip_list:
            ip_info = await get_ip_info(ip, session)
            ip_score, score_description, emoji = await get_ip_score(ip, session)
            
            formatted_message = (
                f"┏━━━━━━━⍟\n"
                f"┃**IP Lookup** ✅\n"
                f"┗━━━━━━━━━━━━⊛\n"
                f"{ip_info}\n"
                f"•➥ɪᴘ sᴄᴏʀᴇ: {ip_score} {emoji} ({score_description})"
            )
            
            checked_ips.append(formatted_message)
            progress['count'] += 1
    progress['done'] = True
    return checked_ips

def extract_ips(text):
    ipv4_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
    ipv6_pattern = r'\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b'
    
    return re.findall(f'{ipv4_pattern}|{ipv6_pattern}', text)

def extract_ips_from_file(file_path):
    with open(file_path, 'r') as f:
        return [ip for line in f for ip in extract_ips(line)]

def is_valid_ip(ip):
    ipv4_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
    ipv6_pattern = r'\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b'
    return re.match(f'{ipv4_pattern}|{ipv6_pattern}', ip)

async def get_ip_info(ip_address, session):
    api_url = f"https://ipinfo.io/{ip_address}?token={IPINFO_TOKEN}"
    try:
        async with session.get(api_url) as response:
            response.raise_for_status()
            data = await response.json()
            info = (
                f"•➥**IP** ➪ `{data.get('ip', 'N/A')}`\n"
                f"•➥**City** ➪ {data.get('city', 'N/A')}\n"
                f"•➥**Region** ➪ {data.get('region', 'N/A')}\n"
                f"•➥**Country** ➪ {data.get('country', 'N/A')}\n"
                f"•➥**Location** ➪ {data.get('loc', 'N/A')}\n"
                f"•➥**Organization** ➪ {data.get('org', 'N/A')}\n"
                f"•➥**Postal Code** ➪ {data.get('postal', 'N/A')}\n"
                f"•➥**Timezone** ➪ {data.get('timezone', 'N/A')}"
            )
            return info
    except aiohttp.ClientError as e:
        print(f"Error fetching IP information: {e}")
    return None

async def get_ip_score(ip_address, session):
    api_url = f"https://ipqualityscore.com/api/json/ip/{IPQUALITYSCORE_API_KEY}/{ip_address}"
    try:
        async with session.get(api_url) as response:
            response.raise_for_status()
            data = await response.json()
            fraud_score = data.get('fraud_score', 'N/A')
            if fraud_score != 'N/A':
                fraud_score = int(fraud_score)
                if fraud_score <= 20:
                    score_description = 'Good'
                    emoji = '✅'
                elif fraud_score <= 60:
                    score_description = 'Moderate'
                    emoji = '⚠️'
                else:
                    score_description = 'Bad'
                    emoji = '❌'
                return fraud_score, score_description, emoji
    except aiohttp.ClientError as e:
        print(f"Error fetching IP score: {e}")
    return None, None, None

def save_checked_ips(checked_ips):
    file_path = 'checked_ips.txt'
    with open(file_path, 'w') as f:
        for ip in checked_ips:
            f.write(f"{ip}\n")
    return file_path


@app.on_message(filters.command(["ipgen"]))
async def generate_ip_handler(client, message):

    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if len(message.command) != 2 or not message.command[1].isdigit():
        await message.reply_text("Please provide a valid number of IPs to generate. Example: /genip 1000")
        return
    
    number_of_ips = int(message.command[1])
    status_message = await message.reply_text(f"**Generating {number_of_ips} IP addresses...**")

    generated_ips = generate_ip_addresses(number_of_ips)
    
    await status_message.delete()
     
    wrapped_ips = [f"`{ip}`" for ip in generated_ips]

    if number_of_ips <= 5:
        ip_list_message = "\n".join(wrapped_ips)
        try:
            await message.reply_text(f"**Generated {number_of_ips} IP addresses:\n{ip_list_message}**")
        except Exception as e:
            print(f"Error sending message: {e}")
    else:
        file_path = save_ips(generated_ips)
        try:
            await message.reply_document(file_path)

            if user_id != OWNER_ID:
                new_credits = user_credits - 1
            await update_user(user_id, {"credits": new_credits})
            
        except Exception as e:
            print(f"Error sending document: {e}")
        os.remove(file_path)


def generate_ip_addresses(n):
    return [".".join(map(str, (random.randint(0, 255) for _ in range(4)))) for _ in range(n)]

def save_ips(ip_list):
    file_path = 'CARD3D_x_Generated_Ips.txt'
    with open(file_path, 'w') as f:
        for ip in ip_list:
            f.write(f"{ip}\n")
    return file_path
