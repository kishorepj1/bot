import re
import aiohttp
from pyrogram import Client, filters
from CARD3D import app
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from pyrogram.enums import ParseMode

CARD_PATTERN = re.compile(r"(\d{6})")

async def get_bin_info(bin_number):
    url = f"https://bins.antipublic.cc/bins/{bin_number}"

    async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
        async with session.get(url) as response:
            if response.status == 200:
                try:
                    bin_info = await response.json()
                    return (
                        bin_info.get("brand", "N/A"),
                        bin_info.get("type", "N/A"),
                        bin_info.get("level", "N/A"),
                        bin_info.get("bank", "N/A"),
                        bin_info.get("country_name", "N/A"),
                        bin_info.get("country_flag", "")
                    )
                except Exception:
                    return "Error parsing BIN info", "N/A", "N/A", "N/A", "N/A", "N/A"
            else:
                return "Error fetching BIN info", "N/A", "N/A", "N/A", "N/A", "N/A"

@app.on_message(filters.command(["bin"], [".", "!", "/"]))
async def check_bin(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1
    bin_number = None

    if message.reply_to_message:

        card_match = re.search(CARD_PATTERN, message.reply_to_message.text)
        if card_match:
            bin_number = card_match.group(1)

    if not bin_number and len(message.command) >= 2:
        bin_number = message.command[1][:6]  

    if not bin_number:
        return await message.reply_text("**Please provide a valid 6-digit BIN or reply to a message with card details.**")

    brand, card_type, level, bank, country, country_flag = await get_bin_info(bin_number)

    initial_message = await message.reply_text("**Processing your request...**")

    await initial_message.edit_text(
        f"𝗕𝗜𝗡 𝗟𝗼𝗼𝗸𝘂𝗽 𝗥𝗲𝘀𝘂𝗹𝘁 🔍\n\n"
        f"𝗕𝗜𝗡 ⇾ `{bin_number}`\n\n"
        f"𝗜𝗻𝗳𝗼 ⇾ `{brand}` - `{card_type}` - `{level}`\n"
        f"𝐈𝐬𝐬𝐮𝐞𝐫 ⇾ `{bank}`\n"
        f"𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ⇾ `{country}` {country_flag}"
    )
