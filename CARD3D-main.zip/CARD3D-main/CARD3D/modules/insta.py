import httpx
from CARD3D import app
from pyrogram import filters
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from pyrogram.enums import ParseMode

DOWNLOADING_STICKER_ID = "CAACAgEAAx0CfD7LAgACO7xmZzb83lrLUVhxtmUaanKe0_ionAAC-gADUSkNORIJSVEUKRrhHgQ"
API_URL = "https://karma-api2.vercel.app/instadl"

@app.on_message(filters.command(["ig", "insta"]))
async def instadl_command_handler(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1


    if len(message.command) < 2:
        await message.reply_text("Usage: /insta [Instagram URL]")
        return

    link = message.command[1]
    try:
        downloading_sticker = await message.reply_sticker(DOWNLOADING_STICKER_ID)

        async with httpx.AsyncClient() as client:
            response = await client.get(API_URL, params={"url": link})
            response.raise_for_status()
            data = response.json()

        content_url = data.get("content_url")
        if content_url:
            content_type = "video" if "video" in content_url else "photo"

            if content_type == "photo":
                await message.reply_photo(content_url)
            elif content_type == "video":
                await message.reply_video(content_url)
            else:
                await message.reply_text("Unsupported content type.")
        else:
            await message.reply_text("Unable to fetch content. Please check the Instagram URL or try with another link.")

    except Exception as e:
        print(e)
        await message.reply_text("An error occurred while processing the request.")

    finally:
        await downloading_sticker.delete()
