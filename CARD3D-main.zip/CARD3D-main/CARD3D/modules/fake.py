

from faker import Faker
from pyrogram import filters
from CARD3D import app
from CARD3D.modules.country_data import COUNTRY_CODES, COUNTRY_CALLING_CODES, FAKER_LOCALES
from config import OWNER_ID
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user

def generate_fake_address(country_code="us"):
    fake_locale = FAKER_LOCALES.get(country_code, "en_US")
    fake = Faker(locale=fake_locale)
    country_name = COUNTRY_CODES.get(country_code, "Unknown Country")
    calling_code = COUNTRY_CALLING_CODES.get(country_code, '')

    state = fake.state() if hasattr(fake, 'state') else "N/A"
    province = fake.province() if hasattr(fake, 'province') else "N/A"
    region = fake.region() if hasattr(fake, 'region') else "N/A"
    formatted_state = next((x for x in [state, province, region] if x != "N/A"), "N/A")

    city = fake.city() if hasattr(fake, 'city') else "N/A"
    town = fake.town() if hasattr(fake, 'town') else "N/A"
    village = fake.village() if hasattr(fake, 'village') else "N/A"
    formatted_city = next((x for x in [city, town, village] if x != "N/A"), "N/A")

    street_address = fake.street_address() if hasattr(fake, 'street_address') else "N/A"
    postcode = fake.postcode() if hasattr(fake, 'postcode') else "N/A"

    username = fake.user_name()
    domain = fake.free_email_domain()
    email = f"{username}@{domain}"

    if calling_code:
        mobile_number = str(fake.random_number(digits=9)).zfill(9)
        generated_number = f"{calling_code}{mobile_number}"
    else:
        generated_number = "N/A"

    return {
        "Name": fake.name(),
        "Gender": fake.random_element(elements=('Male', 'Female')),
        "Street Address": street_address,
        "City/Town/Village": formatted_city,
        "State/Province/Region": formatted_state,
        "Pincode": postcode,
        "Country": country_name,
        "Mobile Number": generated_number,
        "Email": email,
    }

def format_address_details(address_details):
    response = [f"**{address_details['Country']} Address Generated** ✅", "", "▰▰▰▰▰▰▰▰▰▰▰▰▰"]
    for key, value in address_details.items():
        response.append(f"•➥ **{key}**: `{value}`")
    return "\n".join(response)

@app.on_message(filters.command(["fake"], prefixes=[".", "/"]))
async def send_fake_address_details(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(
        user_id, chat_id, required_credits=0
    )
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please use /register first.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    command_text = message.text.split()
    country_code = command_text[1].lower() if len(command_text) > 1 else "us"
    
    if country_code not in COUNTRY_CODES:
        country_code = "us"

    initial_message = await message.reply("**Generating fake address...**")
    address_details = generate_fake_address(country_code)
    formatted_details = format_address_details(address_details)

    await initial_message.edit(formatted_details)
