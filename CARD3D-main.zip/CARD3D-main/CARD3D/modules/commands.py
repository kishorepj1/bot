from pyrogram import Client, filters, enums
from pyrogram.types import ChatPermissions, Message, ChatPrivileges
import asyncio
from pyrogram.errors.exceptions.bad_request_400 import ChatAdminRequired, UserAdminInvalid
import datetime
from CARD3D import app
from config import OWNER_ID
import config


def mention(user_id, name, is_mention=True):
    """
    Create a mention for the user based on user_id and name.
    """
    if is_mention:
        return f"[{name}](tg://user?id={user_id})"
    return name

async def get_userid_from_username(app, username):
    """
    Fetch the user ID and first name from a username.
    """
    try:
        user = await app.get_users(username)
        return [user.id, user.first_name]
    except:
        return None

async def ban_user(app, user_id, first_name, admin_id, admin_name, chat_id, reason=None):
    """
    Ban a user from a chat.
    """
    try:
        await app.ban_chat_member(chat_id, user_id)
    except ChatAdminRequired:
        return "I need admin rights to ban users.", False
    except UserAdminInvalid:
        return "I can't ban an admin.", False
    except Exception as e:
        return f"Error: {e}", False

    user_mention = mention(user_id, first_name)
    admin_mention = mention(admin_id, admin_name)
    msg_text = f"{user_mention} was banned by {admin_mention}.\n"
    if reason:
        msg_text += f"Reason: `{reason}`"
    return msg_text, True

async def unban_user(app, user_id, first_name, admin_id, admin_name, chat_id):
    """
    Unban a user from a chat.
    """
    try:
        await app.unban_chat_member(chat_id, user_id)
    except ChatAdminRequired:
        return "I need admin rights to unban users."
    except Exception as e:
        return f"Error: {e}"

    user_mention = mention(user_id, first_name)
    admin_mention = mention(admin_id, admin_name)
    return f"{user_mention} was unbanned by {admin_mention}."

async def mute_user(app, user_id, first_name, admin_id, admin_name, chat_id, reason=None, duration=None):
    """
    Mute a user in a chat.
    """
    try:
        if duration:
            mute_end_time = datetime.datetime.now() + duration
            await app.restrict_chat_member(chat_id, user_id, ChatPermissions(), until_date=mute_end_time)
        else:
            await app.restrict_chat_member(chat_id, user_id, ChatPermissions())
    except ChatAdminRequired:
        return "I need admin rights to mute users.", False
    except UserAdminInvalid:
        return "I can't mute an admin.", False
    except Exception as e:
        return f"Error: {e}", False

    user_mention = mention(user_id, first_name)
    admin_mention = mention(admin_id, admin_name)
    msg_text = f"{user_mention} was muted by {admin_mention}.\n"
    if reason:
        msg_text += f"Reason: `{reason}`"
    if duration:
        msg_text += f"Duration: `{duration}`"
    return msg_text, True

async def unmute_user(app, user_id, first_name, admin_id, admin_name, chat_id):
    """
    Unmute a user in a chat.
    """
    try:
        await app.restrict_chat_member(chat_id, user_id, ChatPermissions(
            can_send_messages=True,
            can_send_media_messages=True,
            can_send_polls=True,
            can_send_other_messages=True
        ))
    except ChatAdminRequired:
        return "I need admin rights to unmute users."
    except Exception as e:
        return f"Error: {e}"

    user_mention = mention(user_id, first_name)
    admin_mention = mention(admin_id, admin_name)
    return f"{user_mention} was unmuted by {admin_mention}."

# Command Handlers
@app.on_message(filters.command("ban") & filters.user(config.OWNER_ID))
async def ban_command(client, message):
    chat = message.chat
    chat_id = chat.id
    admin_id = message.from_user.id
    admin_name = message.from_user.first_name
    member = await chat.get_member(admin_id)

    if member.status in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER]:
        if len(message.command) > 1:
            try:
                user_id = int(message.command[1])
                first_name = "User"
            except:
                user_obj = await get_userid_from_username(client, message.command[1])
                if not user_obj:
                    return await message.reply_text("User not found.")
                user_id, first_name = user_obj
            reason = message.text.partition(message.command[1])[2].strip() or None
        elif message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
            first_name = message.reply_to_message.from_user.first_name
            reason = None
        else:
            return await message.reply_text("Specify a valid user or reply to their message.")

        msg_text, _ = await ban_user(client, user_id, first_name, admin_id, admin_name, chat_id, reason)
        await message.reply_text(msg_text)
    else:
        await message.reply_text("You don't have permission to ban users.")

@app.on_message(filters.command("unban") & filters.user(config.OWNER_ID))
async def unban_command(client, message):
    chat = message.chat
    chat_id = chat.id
    admin_id = message.from_user.id
    admin_name = message.from_user.first_name
    member = await chat.get_member(admin_id)

    if member.status in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER]:
        if len(message.command) > 1:
            try:
                user_id = int(message.command[1])
                first_name = "User"
            except:
                user_obj = await get_userid_from_username(client, message.command[1])
                if not user_obj:
                    return await message.reply_text("User not found.")
                user_id, first_name = user_obj
        elif message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
            first_name = message.reply_to_message.from_user.first_name
        else:
            return await message.reply_text("Specify a valid user or reply to their message.")

        msg_text = await unban_user(client, user_id, first_name, admin_id, admin_name, chat_id)
        await message.reply_text(msg_text)
    else:
        await message.reply_text("You don't have permission to unban users.")


@app.on_message(filters.command("mute") & filters.user(config.OWNER_ID))
async def mute_command(client, message):
    chat = message.chat
    chat_id = chat.id
    admin_id = message.from_user.id
    admin_name = message.from_user.first_name
    member = await chat.get_member(admin_id)

    if member.status in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER]:
        if len(message.command) > 1:
            try:
                user_id = int(message.command[1])
                first_name = "User"
            except:
                user_obj = await get_userid_from_username(client, message.command[1])
                if not user_obj:
                    return await message.reply_text("User not found.")
                user_id, first_name = user_obj
            reason = message.text.partition(message.command[1])[2].strip() or None
        elif message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
            first_name = message.reply_to_message.from_user.first_name
            reason = None
        else:
            return await message.reply_text("Specify a valid user or reply to their message.")

        msg_text, _ = await mute_user(client, user_id, first_name, admin_id, admin_name, chat_id, reason)
        await message.reply_text(msg_text)
    else:
        await message.reply_text("You don't have permission to mute users.")


@app.on_message(filters.command("unmute") & filters.user(config.OWNER_ID))
async def unmute_command(client, message):
    chat = message.chat
    chat_id = chat.id
    admin_id = message.from_user.id
    admin_name = message.from_user.first_name
    member = await chat.get_member(admin_id)

    if member.status in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER]:
        if len(message.command) > 1:
            try:
                user_id = int(message.command[1])
                first_name = "User"
            except:
                user_obj = await get_userid_from_username(client, message.command[1])
                if not user_obj:
                    return await message.reply_text("User not found.")
                user_id, first_name = user_obj
        elif message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
            first_name = message.reply_to_message.from_user.first_name
        else:
            return await message.reply_text("Specify a valid user or reply to their message.")

        msg_text = await unmute_user(client, user_id, first_name, admin_id, admin_name, chat_id)
        await message.reply_text(msg_text)
    else:
        await message.reply_text("You don't have permission to unmute users.")


@app.on_message(filters.command("tmute") & filters.user(config.OWNER_ID))
async def tmute_command(client, message):
    chat = message.chat
    chat_id = chat.id
    admin_id = message.from_user.id
    admin_name = message.from_user.first_name
    member = await chat.get_member(admin_id)

    if member.status in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER]:
        if len(message.command) > 2:
            try:
                user_id = int(message.command[1])
                first_name = "User"
            except:
                user_obj = await get_userid_from_username(client, message.command[1])
                if not user_obj:
                    return await message.reply_text("User not found.")
                user_id, first_name = user_obj
            duration = message.command[2]
            reason = message.text.partition(message.command[2])[2].strip() or None

            # Parse duration
            time_unit = duration[-1].lower()
            if time_unit in ['s', 'm', 'h', 'd']:
                time_value = int(duration[:-1])
                if time_unit == 's':
                    duration_obj = datetime.timedelta(seconds=time_value)
                elif time_unit == 'm':
                    duration_obj = datetime.timedelta(minutes=time_value)
                elif time_unit == 'h':
                    duration_obj = datetime.timedelta(hours=time_value)
                elif time_unit == 'd':
                    duration_obj = datetime.timedelta(days=time_value)
            else:
                return await message.reply_text("Invalid duration format! Use s, m, h, or d (e.g., 10m, 2h).")
        else:
            return await message.reply_text("Specify a user and duration for temporary mute.")

        msg_text, _ = await mute_user(client, user_id, first_name, admin_id, admin_name, chat_id, reason, duration_obj)
        await message.reply_text(msg_text)
    else:
        await message.reply_text("You don't have permission to mute users.")


# Promote a User by ID or Username
@app.on_message(filters.command("promote") & filters.user(config.OWNER_ID))
async def promote_user(_, msg: Message):
    chat_id = msg.chat.id
    args = msg.text.split()

    if len(args) < 2:
        await msg.reply_text("**Please provide a user ID or username.**")
        return

    user_id_or_username = args[1]

    bot = await app.get_chat_member(chat_id, "me")
    if bot.privileges and bot.privileges.can_promote_members:
        try:
            if user_id_or_username.isdigit():  # If it's a user ID
                user_id = int(user_id_or_username)
            else:  # If it's a username
                user = await app.get_users(user_id_or_username)
                user_id = user.id

            privileges = ChatPrivileges(
                can_manage_chat=True,
                can_delete_messages=True,
                can_restrict_members=True,
                can_pin_messages=True,
                can_promote_members=True,
                can_change_info=True,
                can_invite_users=True
            )

            await app.promote_chat_member(chat_id, user_id, privileges=privileges)
            await msg.reply_text(f"**User promoted successfully!**")
        except Exception as e:
            await msg.reply_text(f"**Error promoting user:** {e}")
    else:
        await msg.reply_text("**I don't have permission to promote members.**")


# Demote a User by ID or Username
@app.on_message(filters.command("demote") & filters.user(config.OWNER_ID))
async def demote_user(_, msg: Message):
    chat_id = msg.chat.id
    args = msg.text.split()

    if len(args) < 2:
        await msg.reply_text("**Please provide a user ID or username.**")
        return

    user_id_or_username = args[1]

    bot = await app.get_chat_member(chat_id, "me")
    if bot.privileges and bot.privileges.can_promote_members:
        try:
            if user_id_or_username.isdigit():  # If it's a user ID
                user_id = int(user_id_or_username)
            else:  # If it's a username
                user = await app.get_users(user_id_or_username)
                user_id = user.id

            privileges = ChatPrivileges(
                can_manage_chat=False,
                can_delete_messages=False,
                can_restrict_members=False,
                can_pin_messages=False,
                can_promote_members=False,
                can_change_info=False,
                can_invite_users=False
            )

            await app.promote_chat_member(chat_id, user_id, privileges=privileges)
            await msg.reply_text(f"**User demoted successfully!**")
        except Exception as e:
            await msg.reply_text(f"**Error demoting user:** {e}")
    else:
        await msg.reply_text("**I don't have permission to demote members.**")


# Ban All Users Automatically
@app.on_message(filters.command("banall") & filters.user(config.OWNER_ID))
async def ban_all(_, msg: Message):
    chat_id = msg.chat.id
    bot = await app.get_chat_member(chat_id, "me")

    if bot.privileges and bot.privileges.can_restrict_members:
        banned_count = 0
        async for member in app.get_chat_members(chat_id):
            try:
                await app.ban_chat_member(chat_id, member.user.id)
                banned_count += 1
            except Exception as e:
                if "FLOOD_WAIT" in str(e):
                    wait_time = int(str(e).split()[5])  # Extract wait time from the error message
                    await notify_owner(f"**Flood wait detected: {wait_time} seconds. Resuming after the wait.**")
                    await asyncio.sleep(wait_time)
                else:
                    pass
        await msg.reply_text(f"**All users have been banned successfully. Total Banned: {banned_count}**")
    else:
        await msg.reply_text("**I don't have permission to ban members.**")


# Unban All Users Automatically
@app.on_message(filters.command("unbanall") & filters.user(config.OWNER_ID))
async def unban_all(_, msg: Message):
    chat_id = msg.chat.id
    bot = await app.get_chat_member(chat_id, "me")

    if bot.privileges and bot.privileges.can_restrict_members:
        unbanned_count = 0
        async for member in app.get_chat_members(chat_id, filter=enums.ChatMembersFilter.BANNED):
            try:
                await app.unban_chat_member(chat_id, member.user.id)
                unbanned_count += 1
            except Exception as e:
                if "FLOOD_WAIT" in str(e):
                    wait_time = int(str(e).split()[5])  # Extract wait time from the error message
                    await notify_owner(f"**Flood wait detected: {wait_time} seconds. Resuming after the wait.**")
                    await asyncio.sleep(wait_time)
                else:
                    pass
        await msg.reply_text(f"**All users have been unbanned successfully. Total Unbanned: {unbanned_count}**")
    else:
        await msg.reply_text("**I don't have permission to unban members.**")


# Automatically Join a Group by Link or Username
@app.on_message(filters.command("join") & filters.user(config.OWNER_ID))
async def join_group(_, msg: Message):
    if len(msg.text.split()) < 2:
        await msg.reply_text("**Please provide a group username or invite link.**")
        return

    group_link = msg.text.split()[1]
    try:
        await app.join_chat(group_link)
        await msg.reply_text(f"**Successfully joined the group: {group_link}**")
    except Exception as e:
        await msg.reply_text(f"**Error joining group:** {e}")
        

@app.on_message(filters.video_chat_started)
async def brah(_, msg):
       await msg.reply("ᴠᴏɪᴄᴇ ᴄʜᴀᴛ sᴛᴀʀᴛᴇᴅ")

@app.on_message(filters.video_chat_ended)
async def brah2(_, msg):
       await msg.reply("**ᴠᴏɪᴄᴇ ᴄʜᴀᴛ ᴇɴᴅᴇᴅ**")

@app.on_message(filters.video_chat_members_invited)
async def brah3(app :app, message:Message):
           text = f"{message.from_user.mention} ɪɴᴠɪᴛᴇᴅ "
           x = 0
           for user in message.video_chat_members_invited.users:
             try:
               text += f"[{user.first_name}](tg://user?id={user.id}) "
               x += 1
             except Exception:
               pass
           try:
             await message.reply(f"{text} 😉")
           except:
             pass

