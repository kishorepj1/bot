import os
import re
import aiohttp
import aiofiles
import requests
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
from pyrogram.enums import ParseMode
from pymongo import MongoClient
from geopy.geocoders import Nominatim
from geopy.distance import great_circle
import whois

from CARD3D import app, BOT_NAME, BOT_USERNAME
from CARD3D.core.mongo import has_premium_access, get_user, LEVELS
from config import OWNER_ID, DEEP_API

mongo_url_pattern = re.compile(r'mongodb(?:\+srv)?:\/\/[^\s]+')

API_KEY = "23nfCEipDijgVv6SH14oktJe"

def check_filename(filename):
    if os.path.exists(filename):
        no = 1
        while True:
            ult = "{0}_{2}{1}".format(*os.path.splitext(filename) + (no,))
            if os.path.exists(ult):
                no += 1
            else:
                return ult
    return filename

async def remove_bg(input_file_name):
    headers = {"X-API-Key": API_KEY}
    files = {"image_file": open(input_file_name, "rb")}
    async with aiohttp.ClientSession() as session:
        async with session.post(
            "https://api.remove.bg/v1.0/removebg", headers=headers, data=files
        ) as response:
            content_type = response.headers.get("content-type")
            if "image" not in content_type:
                return False, await response.json()

            name = check_filename("alpha.png")
            async with aiofiles.open(name, "wb") as file:
                await file.write(await response.read())
            return True, name

def get_pypi_info(package_name):
    try:
        api_url = f"https://pypi.org/pypi/{package_name}/json"
        response = requests.get(api_url)
        return response.json()
    except Exception as e:
        print(f"Error fetching PyPI information: {e}")
        return None

async def check_premium_access(message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, _ = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return None

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please register using  /register in private.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return None

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    return user, user_plan, user_credits, user_plan_symbol

@app.on_message(filters.command("mongochk"))
async def mongo_command(client, message: Message):
    result = await check_premium_access(message)
    if not result:
        return

    if len(message.command) < 2:
        await message.reply("Please enter your MongoDB URL after the command. Example: /mongochk your_mongodb_url")
        return

    mongo_url = message.command[1]
    if re.match(mongo_url_pattern, mongo_url):
        try:
            mongo_client = MongoClient(mongo_url, serverSelectionTimeoutMS=5000)
            mongo_client.server_info()
            await message.reply("MongoDB URL is valid and connection successful ✅")
        except Exception as e:
            await message.reply(f"Failed to connect to MongoDB: {e}")
    else:
        await message.reply("Invalid MongoDB URL format 💔")

@app.on_message(filters.command("rmbg"))
async def rmbg(bot, message):
    result = await check_premium_access(message)
    if not result:
        return

    rmbg_message = await message.reply("Processing...") 
    replied = message.reply_to_message
    if not replied or not (replied.photo or replied.document and "image" in replied.document.mime_type):
        await rmbg_message.edit("Reply to a photo to remove its background")
        return

    photo = await bot.download_media(replied)
    success, result = await remove_bg(photo)
    os.remove(photo)
    if not success:
        error = result["errors"][0]
        details = error.get("detail", "")
        await rmbg_message.edit(f"ERROR ~ {error['title']},\n{details}")
        return

    await message.reply_photo(photo=result, caption="Here is your image without background")
    await message.reply_document(document=result)
    await rmbg_message.delete()
    os.remove(result)

@app.on_message(filters.command("pypi"))
async def pypi_info_command(client, message):
    result = await check_premium_access(message)
    if not result:
        return

    if len(message.command) < 2:
        await message.reply("Please provide a package name after the /pypi command.")
        return

    package_name = message.command[1]
    pypi_info = get_pypi_info(package_name)

    if pypi_info:
        info_message = (
            f"**Package Name:** {pypi_info['info']['name']}\n"
            f"**Latest Version:** {pypi_info['info']['version']}\n"
            f"**Description:** {pypi_info['info']['summary']}\n"
            f"**Project URL:** {pypi_info['info']['project_urls'].get('Homepage', 'N/A')}"
        )
        await message.reply(info_message)
    else:
        await message.reply("Failed to fetch information from PyPI.")

@app.on_message(filters.command("gps"))
async def gps(bot, message):
    result = await check_premium_access(message)
    if not result:
        return

    if len(message.command) < 2:
        await message.reply_text("Example:\n\n/gps [latitude, longitude]")
        return

    coordinates = message.text.split(' ')[1].split(',')
    if len(coordinates) != 2:
        await message.reply_text("Please provide valid latitude and longitude.")
        return

    try:
        geolocator = Nominatim(user_agent="legend-STRIPEHIT")
        location = geolocator.reverse(coordinates, addressdetails=True, zoom=18)
        address = location.raw['address']

        city = address.get('city', '') or address.get('town', '') or address.get('village', '')
        state = address.get('state', '')
        country = address.get('country', '')
        latitude = location.latitude
        longitude = location.longitude

        url = [[InlineKeyboardButton("Open with: 🌏 Google Maps", url=f"https://www.google.com/maps/search/{latitude},{longitude}")]]
        await message.reply_venue(latitude, longitude, city or "Unknown location", f"{state}, {country}", reply_markup=InlineKeyboardMarkup(url))
    except Exception as e:
        await message.reply_text(f"I can't find that location.\nDue to: {e}")

@app.on_message(filters.command("distance"))
async def distance(bot, message):
    result = await check_premium_access(message)
    if not result:
        return

    if len(message.command) < 2:
        await message.reply_text("Example:\n\n/distance [latitude1, longitude1],[latitude2, longitude2]")
        return

    try:
        coords_text = message.text.split(' ')[1]
        coords = coords_text.replace('[', '').replace(']', '').split(',')
        if len(coords) != 4:
            await message.reply_text("Please provide two sets of coordinates.")
            return

        point1 = (float(coords[0]), float(coords[1]))
        point2 = (float(coords[2]), float(coords[3]))
        dist = great_circle(point1, point2).miles

        await message.reply_text(f"Total distance between {point1} and {point2} is {dist:.2f} miles")
    except Exception as e:
        await message.reply_text(f"I can't calculate that distance.\nDue to: {e}")
