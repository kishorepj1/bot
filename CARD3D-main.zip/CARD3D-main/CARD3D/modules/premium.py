import os
from pyrogram import filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.enums import ParseMode
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import CARD3D.core.mongo as mongo
from CARD3D.core.mongo import (
    add_credits,
    remove_credits,
    get_user,
    LEVELS,
    get_premium_users,
    get_all_users,
    reset_all_daily_credits,
    reset_all_credits,
    remove_all_premium_users,
    update_user_plan_by_credits,
    authorize_group,
    remove_group_authorization,
    get_all_authorized_groups,
    generate_redeem_codes,
    redeem_code,
    send_logger_message,
    authorized_groups_collection,
)
from config import OWNER_ID, SUPPORT_CHAT_LINK
from CARD3D import app


def is_owner(user_id):
    return int(user_id) == int(OWNER_ID)


def format_datetime(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else "N/A"


def get_user_plan_info(user_id, user):
    if is_owner(user_id):

        plan = "STRIPEHIT"
        credits = -1
        plan_start_str = "N/A"
        plan_end_str = "Never"
    else:

        plan = user.get("plan", "N/A")
        credits = user.get("credits", 0)
        plan_start = user.get("plan_start", None)
        plan_end = user.get("plan_end", None)
        plan_start_str = format_datetime(plan_start)
        plan_end_str = format_datetime(plan_end) if plan_end else "Never"
    return plan, credits, plan_start_str, plan_end_str


async def handle_user_expiry(message, user_id):
    try:
        if await mongo.check_plan_expiry(user_id):

            await message.reply_text(
                "⚠️ Your premium plan has expired.\nYou have been downgraded to Free plan.",
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True,
            )
            return True
    except Exception as e:
        print(f"Error checking plan expiry for user {user_id}: {e}")
    return False


async def create_or_get_user(user_id, user_name):
    try:
        user = await mongo.get_user(user_id)
        if not user:

            user = await mongo.create_user(user_id, user_name)
        return user, None
    except Exception as e:
        print(f"Error creating or retrieving user {user_id}: {e}")
        return (
            None,
            "Sorry, there was an issue accessing your account. Please try again later.",
        )


@app.on_message(filters.command("premium"))
async def premium_command(client, message):
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    user, error_message = await create_or_get_user(user_id, user_name)
    if error_message:
        await message.reply_text(error_message)
        return

    if user["status"] == "FREE":
        plan_info = f"You are currently a Free user with 15 daily credits.\nPlease use the bot in the [Support chat]({SUPPORT_CHAT_LINK})"
    else:
        plan_info = f"Your current plan is **{user['plan']}**."

    welcome_text = (
        f"Hello {user['name']}! Welcome to the Premium Section 🌟\n\n"
        f"{plan_info}\n\n"
        "💠 **/credits** - Check your current credits and plan status.\n"
        "💠 **/buy** - Purchase a premium plan to access exclusive features.\n"
        "💠 **/features** - View available premium features.\n\n"
        "Admins can use additional commands to manage users and plans."
    )

    await message.reply_text(
        welcome_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("📈 View Plans", callback_data="view_plans")],
                [InlineKeyboardButton("🛒 Buy Plan", callback_data="buy_plan")],
                [InlineKeyboardButton("✨ Features", callback_data="view_features")],
            ]
        ),
    )


@app.on_message(filters.command("credits"))
async def credits_command(client, message):
    user_id = message.from_user.id
    user_name = message.from_user.first_name
    user, error_message = await create_or_get_user(user_id, user_name)
    if error_message:
        await message.reply_text(error_message)
        return
    if user["status"] == "PREMIUM":
        if await handle_user_expiry(message, user_id):
            return

    plan, credits, plan_start, plan_end = get_user_plan_info(user_id, user)
    credits_text = "Unlimited" if credits == -1 else str(credits)

    reply_text = (
        f"💳 **Credits:** {credits_text}\n"
        f"🔐 **Status:** {'Premium' if user.get('status') == 'PREMIUM' else 'Free'}\n"
        f"📋 **Plan:** {plan}\n"
        f"🗓 **Plan Start:** {plan_start}\n"
        f"🗓 **Plan Expires:** {plan_end}\n\n"
        "Need more credits? Click the button below to purchase a premium plan!"
    )

    await message.reply_text(
        reply_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🛒 Buy Premium Plan", callback_data="buy_plan")]]
        ),
    )


@app.on_message(filters.command("info"))
async def info_command(client, message):
    if message.reply_to_message:

        target_user_id = message.reply_to_message.from_user.id
        target_user_name = message.reply_to_message.from_user.first_name
    elif len(message.command) == 2:

        try:
            target_user_id = int(message.command[1])
            fetched_user = await client.get_users(target_user_id)
            target_user_name = fetched_user.first_name
        except Exception:
            return await message.reply_text(
                "Invalid ID format provided.", disable_web_page_preview=True
            )
    else:

        target_user_id = message.from_user.id
        target_user_name = message.from_user.first_name

    user = await get_user(target_user_id)
    if user:

        plan, credits, plan_start, plan_end = get_user_plan_info(target_user_id, user)
        credits_text = "Unlimited" if credits == -1 else str(credits)

        reply_text = (
            f"**User Info on CARD3D 𐏓**\n"
            f"━━━━━━━━━━━━━━\n"
            f"**Name:** {user['name']}\n"
            f"**ID:** `{target_user_id}`\n"
            f"**Credits:** {credits_text}\n"
            f"**Status:** {'Premium' if user.get('status') == 'PREMIUM' else 'Free'}\n"
            f"**Plan:** {plan}\n"
            f"**Plan Start:** {plan_start}\n"
            f"**Plan Expiry:** {plan_end}\n"
        )
        await message.reply_text(
            reply_text, parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True
        )
    else:
        await message.reply_text(
            "User is not registered. Please use /register.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )


@app.on_message(filters.command("remove_all_premium") & filters.user(OWNER_ID))
async def remove_all_premium_command(client, message):
    count = await remove_all_premium_users()
    await message.reply_text(
        f"✅ Removed premium status from {count} users.",
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
    )


@app.on_message(filters.command("add") & filters.user(OWNER_ID))
async def add_credit_command(client, message):
    args = message.text.split()
    if len(args) < 3:
        await message.reply_text(
            "ℹ️ **Usage:** /add `<user_id>` `<amount>`",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return
    try:
        user_id, amount = int(args[1]), int(args[2])
    except ValueError:
        await message.reply_text(
            "❌ **Invalid user ID or amount.** Please ensure both are numbers.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return
    new_credits = await add_credits(user_id, amount)
    if new_credits is not None:
        user = await get_user(user_id)
        plan = user.get("plan", "N/A")
        await message.reply_text(
            f"✅ **Added {amount} credits to {user['name']} (ID: {user_id}).**\n"
            f"**New Balance:** {new_credits} credits.\n"
            f"**Plan:** {plan} - Daily {LEVELS[plan]['daily_credits']} credits for {LEVELS[plan]['duration_days']} days.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
    else:
        await message.reply_text(
            "❌ **Failed to add credits. User not found in the database.**",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )


@app.on_message(filters.command("remove") & filters.user(OWNER_ID))
async def remove_credit_command(client, message):
    args = message.text.split()
    if len(args) < 3:
        await message.reply_text(
            "ℹ️ **Usage:** /remove `<user_id>` `<amount>`",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return
    try:
        user_id, amount = int(args[1]), int(args[2])
    except ValueError:
        await message.reply_text(
            "❌ **Invalid user ID or amount.** Please ensure both are numbers.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return
    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **User not found.** Please check the user ID.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return
    if user.get("credits") == -1:
        await message.reply_text(
            "⚠️ **Cannot modify credits for a user with unlimited credits (STRIPEHIT Plan).**",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return
    new_credits = await remove_credits(user_id, amount)
    if new_credits is not None:
        user = await get_user(user_id)
        plan = user.get("plan", "N/A")
        await message.reply_text(
            f"✅ **Removed {amount} credits from {user['name']} (ID: {user_id}).**\n"
            f"**New Balance:** {new_credits} credits.\n"
            f"**Plan:** {plan}",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
    else:
        await message.reply_text(
            "❌ **Failed to remove credits.**",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )


@app.on_message(filters.command("resetallcredits") & filters.user(OWNER_ID))
async def reset_all_credits_command(client, message):
    await reset_all_credits()
    await message.reply_text(
        "✅ All users' credits have been reset.",
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
    )


@app.on_message(filters.command("viewall") & filters.user(OWNER_ID))
async def viewall_command(client, message):
    try:
        users = await get_all_users()
        if not users:
            await message.reply_text(
                "No users found.",
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True,
            )
            return
        users_info = ""
        for user in users:
            user_id = user.get("user_id")
            name = user.get("name", "N/A")
            plan, credits, plan_start, plan_end = get_user_plan_info(user_id, user)
            credits_text = "Unlimited" if credits == -1 else str(credits)
            users_info += (
                f"👤 User: {name} (ID: {user_id})\n"
                f"Status: {'Premium' if user.get('status') == 'PREMIUM' else 'Free'}\n"
                f"Plan: {plan}\n"
                f"Credits: {credits_text}\n"
                f"Plan Start: {plan_start}\n"
                f"Plan End: {plan_end}\n\n"
            )

        file_name = "all_users_info.txt"
        with open(file_name, "w") as file:
            file.write(users_info)
        await message.reply_document(file_name, caption="All Users List")
        os.remove(file_name)
    except Exception as e:
        await message.reply_text(
            "An error occurred while fetching users.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )


@app.on_message(filters.command("redemption") & filters.user(OWNER_ID))
async def redemption_command(client, message):
    args = message.text.split()
    if len(args) < 2:
        await message.reply_text(
            "Usage: /redemption [plan_number] [amount]\nExample: /redemption 1 10",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return

    try:
        plan_number = int(args[1])
        amount = int(args[2]) if len(args) >= 3 else 1
    except ValueError:
        await message.reply_text(
            "Invalid plan number or amount. Please enter numbers only.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return


    if amount > 50:
        await message.reply_text(
            "⚠️ Cannot generate more than 50 codes at a time to prevent message overflow.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return


    plan_names = [plan for plan in LEVELS if plan not in ["Free", "STRIPEHIT"]]
    plan_name = plan_names[plan_number - 1] if 0 < plan_number <= len(plan_names) else None

    if not plan_name:
        await message.reply_text(
            "Invalid plan number. Please enter a valid plan number.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return


    codes = await generate_redeem_codes(plan_name, amount, prefix="CARD3D")

    if codes:

        codes_text = "\n".join([f"{i+1}. `{code}`" for i, code in enumerate(codes)])


        reply_text = (
            f"**Redeem Codes Generated for {LEVELS[plan_name]['symbol']} {plan_name} Plan**\n"
            f"━━━━━━━━━━━━━━\n\n"
            f"Here are the Redeem Codes:\n\n"
            f"{codes_text}\n"
            f"━━━━━━━━━━━━━━\n\n"
            f"📌 **To redeem a code, use** `/redeem code`\n"
            f"💡 **Example:** `/redeem {codes[0]}`"
        )


        await message.reply_text(
            reply_text,
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )


        await send_logger_message(
            f"Generated {amount} redeem code(s) for {plan_name} by {message.from_user.first_name} (ID: {message.from_user.id})"
        )
    else:
        await message.reply_text(
            "Failed to generate redeem codes.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )


@app.on_message(filters.command("redeem"))
async def redeem_command(client, message):
    args = message.text.split()
    if len(args) != 2:
        await message.reply_text(
            "Usage: /redeem {redeem_code_here}",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        return

    code = args[1].strip()
    user_id = message.from_user.id
    user_name = message.from_user.first_name

    success, msg, plan_name = await redeem_code(user_id, code)

    await message.reply_text(
        msg,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
    )

    if success:

        try:
            await client.send_message(
                chat_id=user_id,
                text=f"🎉 Congratulations {user_name}! You have successfully redeemed the code. Your plan has been updated to **{plan_name}**.",
                parse_mode=ParseMode.MARKDOWN,
            )
        except Exception as e:
            print(f"Error sending private message: {e}")

        await send_logger_message(f"User {user_name} (ID: {user_id}) redeemed code {code} and upgraded to {LEVELS[plan_name]['symbol']} {plan_name} plan.")


@app.on_message(filters.command("id"))
async def getid(client, message):
    chat = message.chat
    your_id = message.from_user.id
    message_id = message.id
    reply = message.reply_to_message

    text = f"**[Message ID:]({message.link})** `{message_id}`\n"
    text += f"**[Your ID:](tg://user?id={your_id})** `{your_id}`\n"
    if len(message.command) == 2:
        try:
            user_to_fetch = message.text.split(None, 1)[1].strip()
            fetched_user = await client.get_users(user_to_fetch)
            text += (
                f"**[User ID:](tg://user?id={fetched_user.id})** `{fetched_user.id}`\n"
            )
        except Exception:
            return await message.reply_text(
                "This user doesn't exist.", quote=True, disable_web_page_preview=True
            )
    text += f"**[Chat ID:](https://t.me/{chat.username})** `{chat.id}`\n\n"
    if reply:
        text += f"**[Replied Message ID:]({reply.link})** `{reply.id}`\n"
        text += f"**[Replied User ID:](tg://user?id={reply.from_user.id})** `{reply.from_user.id}`\n\n"
        if reply.forward_from_chat:
            text += f"The forwarded channel, {reply.forward_from_chat.title}, has an ID of `{reply.forward_from_chat.id}`\n\n"
        if reply.sender_chat:
            text += f"ID of the replied chat/channel is `{reply.sender_chat.id}`"

    await message.reply_text(
        text, disable_web_page_preview=True, parse_mode=ParseMode.MARKDOWN
    )

# --------------------------- Group Authorization Commands (Owner Only) ---------------------------


@app.on_message(filters.command("authgc") & filters.user(OWNER_ID))
async def authorize_group_command(client, message):
    if len(message.command) < 2:
        await message.reply_text("Usage: /authgc <chat_id> [broadcast]")
        return
    try:
        chat_id = int(message.command[1])
        broadcast_enabled = False
        if len(message.command) == 3 and message.command[2].lower() == "broadcast":
            broadcast_enabled = True
        chat = await client.get_chat(chat_id)
        success = await authorize_group(chat_id, chat.title, broadcast_enabled)
        if success:
            await message.reply_text(f"✅ Authorized group: {chat.title} (ID: {chat_id}). Broadcast Enabled: {broadcast_enabled}")
        else:
            await message.reply_text("Failed to authorize the group.")
    except Exception as e:
        await message.reply_text(f"Error: {e}")


@app.on_message(filters.command("unauthgc") & filters.user(OWNER_ID))
async def unauthorize_group_command(client, message):
    if len(message.command) != 2:
        await message.reply_text("Usage: /unauthgc <chat_id>")
        return
    try:
        chat_id = int(message.command[1])
        success = await remove_group_authorization(chat_id)
        if success:
            await message.reply_text(f"✅ Un-authorized group ID: {chat_id}.")
        else:
            await message.reply_text("Group was not authorized.")
    except Exception as e:
        await message.reply_text(f"Error: {e}")


@app.on_message(filters.command("listauthgc") & filters.user(OWNER_ID))
async def list_authorized_groups_command(client, message):
    groups = await get_all_authorized_groups()
    if not groups:
        await message.reply_text("No authorized groups.")
        return

    response = "**Authorized Groups:**\n"
    for group in groups:
        broadcast_status = group.get('broadcast_enabled', False)
        response += f"- {group.get('chat_title', 'N/A')} (ID: `{group['chat_id']}`) - Broadcast: {'Enabled' if broadcast_status else 'Disabled'}\n"
    await message.reply_text(response, parse_mode=ParseMode.MARKDOWN)


@app.on_message(filters.command("set_broadcast") & filters.user(OWNER_ID))
async def set_broadcast_command(client, message):
    if len(message.command) != 3:
        await message.reply_text("Usage: /set_broadcast <chat_id> <on/off>")
        return
    try:
        chat_id = int(message.command[1])
        status = message.command[2].lower()
        if status not in ["on", "off"]:
            await message.reply_text("Invalid status. Use 'on' or 'off'.")
            return
        broadcast_enabled = True if status == "on" else False
        result = await authorized_groups_collection.update_one(
            {"chat_id": chat_id},
            {"$set": {"broadcast_enabled": broadcast_enabled}}
        )
        if result.matched_count > 0:
            await message.reply_text(f"✅ Set broadcast status to {'Enabled' if broadcast_enabled else 'Disabled'} for group ID {chat_id}.")
        else:
            await message.reply_text("Group not found. Please authorize the group first.")
    except Exception as e:
        await message.reply_text(f"Error: {e}")

# --------------------------- End of Group Authorization Commands ---------------------------


@app.on_message(filters.command("features"))
async def features_command(client, message):

    features_text = (
        "**✨ Premium Features Overview**\n"
        "━━━━━━━━━━━━━━\n\n"
        "**Access to Premium Files Without Limits**\n"
        "💠 Premium files with unlimited access.\n\n"
        "**Payment Gateways**\n"
        "💠 Braintree\n"
        "💠 Stripe (Site-based)\n"
        "💠 Stripe (SK-based)\n"
        "💠 Stripe Auth\n"
        "💠 VBV\n\n"
        "**Mass Checker Premiums**\n"
        "💠 Mass Scraper\n"
        "💠 Mass CC Generator\n"
        "💠 Mass Stripe Auth\n"
        "💠 Mass Stripe Site-based\n"
        "💠 Mass SK-based\n"
        "💠 Mass Braintree\n"
        "💠 Mass VBV\n\n"
        "**Txt-Based Checker Premium Levels**\n"
        "💠 Bronze 🥉 - 2,000 CC in txt files\n"
        "💠 Silver 🥈 - 4,000 CC in txt files\n"
        "💠 Platinum 🔮 - 9,500 CC in txt files\n"
        "💠 Diamond 💎 - 22,500 CC in txt files\n"
        "💠 VCLUB ♾️ - Unlimited Access\n\n"
        "**Files**\n"
        "💠 SK-based Txt\n"
        "💠 Stripe Site-based Txt\n"
        "💠 Braintree Txt\n"
        "💠 SK Txt Checker\n"
    )

    await message.reply_text(
        features_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("⬅️ Back to Premium", callback_data="go_back")]]
        ),
    )


@app.on_message(filters.command("buy"))
async def buy_command(client, message):
    user_id = message.from_user.id

    plans_text = "**🛒 Available Premium Plans**\n\n"
    plans_text += "\n".join(
        [
            f"{LEVELS[plan]['symbol']} **{plan}** - ${LEVELS[plan]['price']} for {LEVELS[plan]['duration_days']} days\n"
            f"📈 Daily Credits: {LEVELS[plan]['credits']}"
            for plan in LEVELS
            if plan not in ["STRIPEHIT", "Free"]
        ]
    )
    if is_owner(user_id):
        plans_text += "\n\n💠 **STRIPEHIT** - Unlimited credits."

    await message.reply_text(
        plans_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("📈 View Plans", callback_data="view_plans")],
                [
                    InlineKeyboardButton(
                        "💬 Contact Support", url="https://t.me/STRIPEHIT"
                    )
                ],
            ]
        ),
    )

# --------------------------- Callback Query Handlers ---------------------------


@app.on_callback_query(filters.regex("buy_plan"))
async def buy_plan_callback(client, callback_query):

    payment_info = (
        "📝 **Payment Methods:**\n"
        "━━━━━━━━━━━━━━\n\n"
        "💰 **BINANCE ID/PAY:** `OFF NOW`\n"
        "💰 **Bitcoin (BTC):** `bc1qh36jqdvv25dfx0nx258jsrhy5n6pfcc8tdep89`\n"
        "💰 **USDT (TRC20):** `TYJ6Jk8wsJArSxnidTwNgsG2QST5oKdBfR`\n"
        "💰 **Litecoin (LTC):** `LZirvuF6VfXuNBmhVY2eU16mxZ25TeZHQL`\n"
        "💰 **UPI:** `daxxsir@axl`\n\n"
        "If you need other payment methods, please contact support.\n\n"
        "📌 **Note:** After completing the payment, click Contact Support and send the transaction screenshot along with your Telegram ID."
    )

    await callback_query.message.edit_text(
        payment_info,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "💬 Contact Support", url="https://t.me/STRIPEHIT"
                    )
                ],
                [InlineKeyboardButton("⬅️ Back", callback_data="go_back")],
            ]
        ),
    )
    await callback_query.answer()

@app.on_message(filters.command("premium_users") & filters.user(OWNER_ID))
async def premium_users_command(client, message):
    try:
        premium_users = await get_premium_users()
        if not premium_users:
            await message.reply_text(
                "No premium users found.",
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True,
            )
            return
        users_info = "**Premium Users and Their Plans:**\n\n"
        for user in premium_users:
            user_id = user.get("user_id")
            name = user.get("name", "N/A")
            plan, credits, plan_start, plan_end = get_user_plan_info(user_id, user)
            credits_text = "Unlimited" if credits == -1 else str(credits)
            users_info += (
                f"👤 **User:** {name} (ID: `{user_id}`)\n"
                f"🔐 **Status:** {'Premium' if user.get('status') == 'PREMIUM' else 'Free'}\n"
                f"📋 **Plan:** {plan}\n"
                f"💳 **Credits:** {credits_text}\n"
                f"🗓 **Plan Start:** {plan_start}\n"
                f"🗓 **Plan End:** {plan_end}\n\n"
            )
        if len(users_info) > 4096:
            file_name = "premium_users_info.txt"
            with open(file_name, "w") as file:
                file.write(users_info)
            await message.reply_document(file_name, caption="Premium Users List")
            os.remove(file_name)
        else:
            await message.reply_text(
                users_info, parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True
            )
    except Exception as e:
        await message.reply_text(
            "An error occurred while fetching premium users.",
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
        )
        

@app.on_callback_query(filters.regex("view_credits"))
async def view_credits_callback(client, callback_query):
    user_id = callback_query.from_user.id
    user, error_message = await create_or_get_user(
        user_id, callback_query.from_user.first_name
    )
    if error_message:
        await callback_query.message.edit_text(
            error_message, parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True
        )
        return
    if user.get("status") == "PREMIUM":
        if await handle_user_expiry(callback_query.message, user_id):
            return

    credits = user.get("credits", 0)
    credits_text = "Unlimited" if credits == -1 else str(credits)
    plan = user.get("plan", "N/A")
    plan_start = format_datetime(user.get("plan_start"))
    plan_end = format_datetime(user.get("plan_end"))

    reply_text = (
        f"💳 **Credits:** {credits_text}\n"
        f"🔐 **Status:** {'Premium' if user.get('status') == 'PREMIUM' else 'Free'}\n"
        f"📋 **Plan:** {plan}\n"
        f"🗓 **Plan Start:** {plan_start}\n"
        f"🗓 **Plan Expires:** {plan_end}\n\n"
        "Need more credits? Click the button below to purchase a premium plan!"
    )

    await callback_query.message.edit_text(
        reply_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("🛒 Buy Premium Plan", callback_data="buy_plan")],
                [InlineKeyboardButton("⬅️ Back", callback_data="go_back")],
            ]
        ),
    )
    await callback_query.answer()


@app.on_callback_query(filters.regex("view_plans"))
async def view_plans_callback(client, callback_query):
    user_id = callback_query.from_user.id

    plans_text = "**📈 Available Premium Plans:**\n\n"
    for plan, details in LEVELS.items():
        if plan == "STRIPEHIT" and not is_owner(user_id):
            continue
        plans_text += (
            f"{details['symbol']} **{plan}**\n"
            f"💰 **Price:** ${details['price']}\n"
            f"⏳ **Duration:** {details['duration_days']} days\n"
            f"📈 **Daily Credits:** {details['credits'] if details['credits'] != -1 else 'Unlimited'}\n\n"
        )

    await callback_query.message.edit_text(
        plans_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("🛒 Buy Plan", callback_data="buy_plan")],
                [InlineKeyboardButton("⬅️ Back", callback_data="go_back")],
            ]
        ),
    )
    await callback_query.answer()


@app.on_callback_query(filters.regex("view_features"))
async def view_features_callback(client, callback_query):

    features_text = (
        "**✨ Premium Features Overview**\n"
        "━━━━━━━━━━━━━━\n\n"
        "**Access to Premium Files Without Limits**\n"
        "💠 Premium files with unlimited access.\n\n"
        "**Payment Gateways**\n"
        "💠 Braintree\n"
        "💠 Stripe (Site-based)\n"
        "💠 Stripe (SK-based)\n"
        "💠 Stripe Auth\n"
        "💠 VBV\n\n"
        "**Mass Checker Premiums**\n"
        "💠 Mass Scraper\n"
        "💠 Mass CC Generator\n"
        "💠 Mass Stripe Auth\n"
        "💠 Mass Stripe Site-based\n"
        "💠 Mass SK-based\n"
        "💠 Mass Braintree\n"
        "💠 Mass VBV\n\n"
        "**Txt-Based Checker Premium Levels**\n"
        "💠 Bronze 🥉 - 2000 CC in txt files\n"
        "💠 Silver 🥈 - 5000 CC in txt files\n"
        "💠 Gold 🥇 - 10000 CC in txt files\n"
        "💠 Platinum 🔮 - 22,500 CC in txt files\n"
        "💠 Diamond 💎 - 30,000 CC in txt files\n"
        "💠 Jarvis ♾️ - Unlimited Access\n\n"
        "**Files**\n"
        "💠 SK-based Txt\n"
        "💠 Stripe Site-based Txt\n"
        "💠 Braintree Txt\n"
        "💠 SK Txt Checker\n"
    )

    await callback_query.message.edit_text(
        features_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("⬅️ Back to Premium", callback_data="go_back")]]
        ),
    )

    await callback_query.answer() 


@app.on_callback_query(filters.regex("go_back"))
async def go_back_callback(client, callback_query):
    user_id = callback_query.from_user.id
    user, error_message = await create_or_get_user(
        user_id, callback_query.from_user.first_name
    )
    if error_message:
        await callback_query.message.edit_text(
            error_message, parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True
        )
        return

    if user["status"] == "FREE":
        plan_info = f"You are currently a Free user with 15 daily credits.\nPlease use the bot in the [Support chat]({SUPPORT_CHAT_LINK})"
    else:
        plan_info = f"Your current plan is **{user['plan']}**."

    welcome_text = (
        f"Hello {user['name']}! Welcome to the Premium Section 🌟\n\n"
        f"{plan_info}\n\n"
        "💠 **/credits** - Check your current credits and plan status.\n"
        "💠 **/buy** - Purchase a premium plan to access exclusive features.\n"
        "💠 **/features** - View available premium features.\n\n"
        "Admins can use additional commands to manage users and plans."
    )

    await callback_query.message.edit_text(
        welcome_text,
        parse_mode=ParseMode.MARKDOWN,
        disable_web_page_preview=True,
        reply_markup=InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("📈 View Plans", callback_data="view_plans")],
                [InlineKeyboardButton("🛒 Buy Plan", callback_data="buy_plan")],
                [InlineKeyboardButton("✨ Features", callback_data="view_features")],
            ]
        ),
    )
    await callback_query.answer()

# --------------------------- End of Callback Query Handlers ---------------------------


scheduler = AsyncIOScheduler()

@scheduler.scheduled_job("cron", hour=0, minute=0, timezone="Asia/Kolkata")
async def scheduled_daily_tasks():
    await reset_all_daily_credits()
    print("✅ Daily credits reset completed.")

scheduler.start()
