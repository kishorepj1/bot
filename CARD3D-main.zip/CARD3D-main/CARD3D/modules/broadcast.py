from pyrogram import filters
from pyrogram.enums import ParseMode
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from CARD3D import app
import asyncio
from CARD3D.core.mongo import get_all_user_ids, get_all_broadcast_chats
from config import OWNER_ID

BROADCAST_DATA = {}

@app.on_message(filters.command("broadcast") & filters.user(OWNER_ID))
async def broadcast_message(client, message):
    if not message.reply_to_message:
        await message.reply_text("⚠️ **Please reply to the message you want to broadcast.**")
        return

    broadcast_msg = message.reply_to_message

    user_ids = await get_all_user_ids()
    total_users = len(user_ids)

    chat_ids = await get_all_broadcast_chats()
    total_chats = len(chat_ids)

    total_recipients = total_users + total_chats

    if total_recipients == 0:
        await message.reply_text("❌ **No users or chats found to broadcast to.**")
        return

    keyboard = InlineKeyboardMarkup(
        [[
            InlineKeyboardButton("✅ Yes", callback_data=f"confirm_broadcast_{message.id}"),
            InlineKeyboardButton("❌ No", callback_data=f"cancel_broadcast_{message.id}")
        ]]
    )

    confirmation_message = await message.reply_text(
        f"Are you sure you want to broadcast this message to `{total_recipients}` recipients (Users: {total_users}, Chats: {total_chats})?",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=keyboard
    )

    BROADCAST_DATA[message.id] = {
        "broadcast_msg": broadcast_msg,
        "user_ids": user_ids,
        "chat_ids": chat_ids,
        "total_recipients": total_recipients,
        "confirmation_message_id": confirmation_message.id,
        "chat_id": confirmation_message.chat.id
    }

@app.on_callback_query(filters.regex(r"^(confirm|cancel)_broadcast_(\d+)$"))
async def handle_confirmation(client, callback_query: CallbackQuery):
    action, message_id = callback_query.data.split("_broadcast_")
    message_id = int(message_id)

    if callback_query.from_user.id != OWNER_ID:
        await callback_query.answer("You're not authorized to confirm this action!", show_alert=True)
        return

    if message_id not in BROADCAST_DATA:
        await callback_query.answer("This broadcast request has expired or is invalid.", show_alert=True)
        return

    data = BROADCAST_DATA.pop(message_id)

    confirmation_message = await client.get_messages(
        chat_id=data["chat_id"],
        message_ids=data["confirmation_message_id"]
    )

    if action == "confirm":
        await confirmation_message.edit(f"📣 **Broadcasting message to {data['total_recipients']} recipients...**", reply_markup=None)

        success = 0
        failed = 0

        recipients = data["user_ids"] + data["chat_ids"]
        broadcast_msg = data["broadcast_msg"]

        for idx, recipient_id in enumerate(recipients):
            try:
                await broadcast_msg.copy(chat_id=recipient_id)
                success += 1
            except Exception as e:
                failed += 1

            if idx % 20 == 0:
                await asyncio.sleep(1)
            else:
                await asyncio.sleep(0.1)

        await confirmation_message.edit(
            f"✅ **Broadcast completed.**\n\n"
            f"**Successful Sends:** `{success}`\n"
            f"**Failed Sends:** `{failed}`",
            parse_mode=ParseMode.MARKDOWN
        )

    elif action == "cancel":
        await confirmation_message.edit("❌ **Broadcast cancelled.**", reply_markup=None)

    await callback_query.answer()
