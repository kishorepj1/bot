import time
import psutil
from pyrogram import filters
from pyrogram.types import Message
from config import OWNER_ID
from CARD3D import app, BOT_NAME, BOT_USERNAME
from CARD3D.core.mongo import (get_total_users, get_premium_users_count,)
from pyrogram.enums import ParseMode

_boot_ = time.time()

def get_readable_time(seconds):
    minutes, seconds = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    tmp = (
        (str(days) + "d, ") if days else ""
    ) + (
        (str(hours) + "h, ") if hours else ""
    ) + (
        (str(minutes) + "m, ") if minutes else ""
    ) + (
        (str(seconds) + "s") if seconds else ""
    )
    return tmp or "0s"


@app.on_message(filters.command("ping", [".", "/", "!"]) & filters.user(OWNER_ID))
async def send_stats_message(client, message: Message):
    processing_msg = await message.reply_text("`Fetching bot stats, please wait...`")

    bot_uptime = int(time.time() - _boot_)
    total_users = await get_total_users()
    premium_users_count = await get_premium_users_count()

    stats = {
        "UP": get_readable_time(bot_uptime),
        "CPU": f"{psutil.cpu_percent(percpu=False)}%",  
        "RAM": f"{psutil.virtual_memory().percent}%",
        "DISK": f"{psutil.disk_usage('/').percent}%",
        "USERS": total_users,
        "PREMIUM_USERS": premium_users_count,
    }

    response_text = f"""
**[{BOT_NAME}](https://t.me/{BOT_USERNAME}) ɪs ᴀʟɪᴠᴇ!**
▰▰▰▰▰▰▰▰▰▰▰▰▰
**sʏsᴛᴇᴍ sᴛᴀᴛs :**\n
**↬ ᴜᴩᴛɪᴍᴇ :** {stats['UP']}
**↬ ʀᴀᴍ :** {stats['RAM']}
**↬ ᴄᴩᴜ :** {stats['CPU']}
**↬ ᴅɪsᴋ :** {stats['DISK']}
▰▰▰▰▰▰▰▰▰▰▰▰▰

━━━━━━━━━━━━━━━━━━━━
**ᴜsᴇʀ sᴛᴀᴛs:**

**↬ ᴛᴏᴛᴀʟ ᴜsᴇʀs:** {stats['USERS']}
**↬ ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀs:** {stats['PREMIUM_USERS']}
━━━━━━━━━━━━━━━━━━━━
**🥀 ʙᴏᴛ ʙʏ** : [ᴊᴀʀᴠɪs](https://t.me/{OWNER_ID})
"""

    await processing_msg.edit(text=response_text, disable_web_page_preview=True)
