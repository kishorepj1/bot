import asyncio
import base64
import mimetypes
import os
from typing import Union, Tuple, List
from pyrogram import filters, types as t
from lexica import AsyncClient
from CARD3D import app
from lexica.constants import languageModels
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from pyrogram.enums import ParseMode

async def chat_completion(prompt: str, model: str) -> Union[Tuple[str, List[str]], str]:
    try:
        model_info = getattr(languageModels, model)
        client = AsyncClient()
        output = await client.ChatCompletion(prompt, model_info)
        if model == "bard":
            return output['content'], output['images']
        return output['content']
    except Exception as e:
        raise Exception(f"API error: {e}")


async def gemini_vision(prompt: str, model: str, images: List[str]) -> str:
    image_info = []
    for image in images:
        with open(image, "rb") as image_file:
            data = base64.b64encode(image_file.read()).decode("utf-8")
            mime_type, _ = mimetypes.guess_type(image)
            image_info.append({
                "data": data,
                "mime_type": mime_type
            })
        os.remove(image)
    payload = {
        "images": image_info
    }
    model_info = getattr(languageModels, model)
    client = AsyncClient()
    output = await client.ChatCompletion(prompt, model_info, json=payload)
    return output['content']['parts'][0]['text']


def get_media(message: t.Message) -> Union[t.Photo, t.Document, None]:
    """Extract Media"""
    media = None
    if message.media:
        if message.photo:
            media = message.photo
        elif (message.document and message.document.mime_type in ['image/png', 'image/jpg', 'image/jpeg'] and
              message.document.file_size < 5242880):
            media = message.document
    elif message.reply_to_message and message.reply_to_message.media:
        if message.reply_to_message.photo:
            media = message.reply_to_message.photo
        elif (message.reply_to_message.document and message.reply_to_message.document.mime_type in ['image/png',
                                                                                                  'image/jpg',
                                                                                                  'image/jpeg'] and
              message.reply_to_message.document.file_size < 5242880):
            media = message.reply_to_message.document
    return media


def get_text(message: t.Message) -> Union[str, None]:
    """Extract Text From Commands"""
    if message.text is None:
        return None
    if " " in message.text:
        try:
            return message.text.split(None, 1)[1]
        except IndexError:
            return None
    else:
        return None


@app.on_message(filters.command(["bard", "gpt", "llama", "mistral", "palm", "gemini"]))
async def chat_bots(_, m: t.Message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1 
    prompt = get_text(m)
    media = get_media(m)
    if media is not None:
        return await ask_about_image(_, m, [media], prompt)
    if prompt is None:
        return await m.reply_text("Hello, how can I assist you today?")
    model = m.command[0].lower()
    output = await chat_completion(prompt, model)
    if model == "bard":
        output, images = output
        if len(images) == 0:
            return await m.reply_text(output)
        media = [t.InputMediaPhoto(i) for i in images]
        media[0] = t.InputMediaPhoto(images[0], caption=output)
        await _.send_media_group(
            m.chat.id,
            media,
            reply_to_message_id=m.message_id
        )
    else:
        await m.reply_text(output if model != "gemini" else output['parts'][0]['text'])


async def ask_about_image(_, m: t.Message, media_files: List[Union[t.Photo, t.Document]], prompt: str):
    images = []
    for media in media_files:
        image = await _.download_media(media.file_id, file_name=f'./downloads/{m.from_user.id}_ask.jpg')
        images.append(image)
    output = await gemini_vision(prompt if prompt else "What's this?", "geminiVision", images)
    await m.reply_text(output)
