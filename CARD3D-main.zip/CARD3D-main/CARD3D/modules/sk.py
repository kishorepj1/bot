import re
import time
import requests
from requests.auth import HTTPBasicAuth
from pyrogram import Client, filters, enums
from CARD3D import app
from config import OWNER_ID
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS

def retrieve_balance(sk):
    url = "https://api.stripe.com/v1/balance"
    auth = HTTPBasicAuth(sk, "")
    response = requests.get(url, auth=auth)
    return response.json()


def retrieve_publishable_key_and_merchant(sk):
    price_url = "https://api.stripe.com/v1/prices"
    headers = {"Authorization": f"Bearer {sk}"}
    price_data = {
        "currency": "usd",
        "unit_amount": 1000,
        "product_data[name]": "Gold Plan",
    }

    price_response = requests.post(price_url, headers=headers, data=price_data)
    if price_response.status_code != 200:
        error = price_response.json().get("error", {})
        code = error.get("code", "")
        message = error.get("message", "")

        if (
            code in ("api_key_expired", "payment_link_no_valid_payment_methods")
            or "Invalid API Key provided" in message
        ):
            raise Exception(f"{code}: {message}")

        raise Exception(f"{error.get('type', 'error')}: {message}")

    payment_link_url = "https://api.stripe.com/v1/payment_links"
    payment_link_data = {
        "line_items[0][quantity]": 1,
        "line_items[0][price]": price_response.json()["id"],
    }
    payment_link_response = requests.post(
        payment_link_url, headers=headers, data=payment_link_data
    )

    if payment_link_response.status_code != 200:
        error = payment_link_response.json().get("error", {})
        if error.get("code") == "payment_link_no_valid_payment_methods":
            return None, None
        raise Exception(f"Failed to create payment link: {payment_link_response.text}")

    payment_link_id = payment_link_response.json()["url"].split("/")[-1]
    merchant_response = requests.get(
        f"https://merchant-ui-api.stripe.com/payment-links/{payment_link_id}"
    )

    if merchant_response.status_code != 200:
        raise Exception(
            f"Failed to retrieve publishable key and merchant: {merchant_response.text}"
        )

    data = merchant_response.json()
    return data.get("key"), data.get("merchant")


async def check_status(message, sk, user_id, user_plan, user_plan_symbol):
    start_time = time.perf_counter()
    publishable_key, merchant = None, None
    status, resp = "SK Dead ❌", "Unknown error"

    try:
        publishable_key, merchant = retrieve_publishable_key_and_merchant(sk)
        if publishable_key:
            status = "SK Live ✅"
            resp = "This SK is live and functional."
        else:
            status = "Test Mode ⚙️"
            resp = "Your account cannot currently make live charges."
    except Exception as e:
        error_response = str(e)

        error_mapping = {
            "API Key Expired": ("SK Dead ❌", "API Key Expired"),
            "Expired API Key provided": ("SK Dead ❌", "Expired API Key"),
            "Invalid API Key": ("SK Dead ❌", "Invalid API Key"),
            "Account Country Not Supported": (
                "Integration Off ⚠️",
                "Account Country Not Supported",
            ),
            "Publishable Key Misuse": ("Test Mode ⚙️", "Publishable Key Misuse"),
            "Account Restricted from Live Charges": (
                "SK Dead ❌",
                "Account Restricted from Live Charges",
            ),
            "Account Not Activated": ("SK Dead ❌", "Account Not Activated"),
            "Rate Limit Exceeded": ("SK Rate Limited 🚨", "Rate Limit Exceeded"),
            "API Key Revoked": ("SK Dead ❌", "API Key Revoked"),
            "Permission Denied": ("Access Denied 🚫", "Permission Denied"),
            "Account Suspended": ("Account Suspended ⛔", "Account Suspended"),
            "Currency Not Supported": ("Integration Off ⚠️", "Currency Not Supported"),
            "Insufficient Permissions": ("Access Denied 🚫", "Insufficient Permissions"),
            "Invalid Request": ("Invalid Request 🚫", "Invalid Request"),
            "Duplicate Transaction": ("Transaction Error ⚠️", "Duplicate Transaction"),
            "Missing Required Parameter": (
                "Invalid Request 🚫",
                "Missing Required Parameter",
            ),
            "API Internal Error": ("Server Error ⚠️", "API Internal Error"),
            "Network Error": ("Network Issue 🌐", "Network Error"),
            "Payment Method Not Supported": (
                "Payment Issue ⚠️",
                "Payment Method Not Supported",
            ),
            "This account isn't enabled to make cross border transactions": (
                "Integration OFF ⚠️",
                "This account isn't enabled to make cross border transactions",
            ),
        }

        for error_message, (stat, response) in error_mapping.items():
            if error_message in error_response:
                status, resp = stat, response
                break

    balance_data = retrieve_balance(sk)

    if "rate_limit" in balance_data:
        status, resp = "**RATE LIMIT**⚠️", "Rate limit exceeded"

    try:
        available_balance = balance_data["available"][0]["amount"] / 100
        pending_balance = balance_data["pending"][0]["amount"] / 100
        currency = balance_data["available"][0]["currency"]
    except KeyError:
        available_balance, pending_balance, currency = (
            "Not Available",
            "Not Available",
            "Not Available",
        )

    end_time = time.perf_counter()
    elapsed_time = end_time - start_time

    response_text = (
        "┏━━━━━━━⍟\n"
        "┃  **sᴋ ʟᴏᴏᴋᴜᴘ** ✅ \n"
        "┗━━━━━━━━━━━⊛\n\n"
        f"**⊙ SK Status** ➜ **{status}**\n"
        f"**⊙ Response** ➜ {resp}\n\n"
        f"**⊙ SK Key** ➜ `{sk}`\n"
        f"**⊙ Publishable Key** ➜ `{publishable_key or 'Not Available'}`\n"
        f"**⊙ Currency** ➜ {currency}\n"
        f"**⊙ Available Balance** ➜ {available_balance}$\n"
        f"**⊙ Pending Balance** ➜ {pending_balance}$\n"
        f"**⊙ Time Taken** ➜ {elapsed_time:.2f} seconds\n"
        f"**⊙ ᴄʜᴇᴄᴋᴇᴅ ʙʏ** ➜ [{message.from_user.first_name}](tg://user?id={user_id}) ⤿ {user_plan} {user_plan_symbol} ⤾"
    )

    return response_text


@app.on_message(filters.command("sk", prefixes=[".", "/", "!"]))
async def sk_checker(client, message):

    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(
        user_id, chat_id, required_credits=0
    )
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please register using  /register in private.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    sk_match = None

    if message.reply_to_message:
        sk_match = re.search(r"sk_live_[a-zA-Z0-9]+", message.reply_to_message.text)

    if not sk_match:
        sk_match = re.search(r"sk_live_[a-zA-Z0-9]+", message.text)

    if not sk_match:
        await message.reply("Please provide a valid secret key.")
        return

    sk = sk_match.group(0)

    response = await check_status(message, sk, user_id, user_plan, user_plan_symbol)

    if user_id != OWNER_ID:
            new_credits = user_credits - 1
            await update_user(user_id, {"credits": new_credits})

    await message.reply(
        response, parse_mode=enums.ParseMode.MARKDOWN, disable_web_page_preview=True
    )
