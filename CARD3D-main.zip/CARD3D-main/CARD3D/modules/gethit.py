import os
import re
from pyrogram import filters
from CARD3D import app
from config import OWNER_ID
from pyrogram.enums import ParseMode
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS


card_pattern = re.compile(r"(\d{15,16})[|/:](\d{1,2})[|/:](\d{2,4})[|/:](\d{3,4})")
sk_key_pattern = re.compile(r"sk_live_[a-zA-Z0-9]+")

@app.on_message(filters.command("gethits", prefixes=[".", "/"]))
async def get_live_items(client, message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(
        user_id, chat_id, required_credits=0
    )
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text(
            "❌ **You are not registered. Please register using  /register in private.**",
            parse_mode=ParseMode.MARKDOWN,
        )
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get("symbol", "")

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if len(message.command) != 2:
        await message.reply_text("Please provide the unique ID in the format: /gethits {prefix}_{unique_id}")
        return

    unique_id_full = message.command[1]
    temp_file_path = None
    live_item_count = 0
    charge_item_count = 0
    item_type = None

    if unique_id_full.startswith("xvvtxt_"):
        unique_id = unique_id_full.replace("xvvtxt_", "")
        temp_file_path = os.getenv(f'LIVE_AND_CHARGE_CARDS_FILE_{unique_id}')
        item_type = 'card'

        if temp_file_path and os.path.exists(temp_file_path):

            if os.path.getsize(temp_file_path) == 0:
                await message.reply("The live items file is empty. No live items found.")
                os.remove(temp_file_path)
                return

            with open(temp_file_path, 'r') as file:
                for line in file:
                    if "Charge Cards:" in line:

                        for charge_line in file:
                            if card_pattern.search(charge_line):
                                charge_item_count += 1
                    elif "Live Cards:" in line:

                        for live_line in file:
                            if card_pattern.search(live_line):
                                live_item_count += 1

            with open(temp_file_path, 'rb') as file:
                caption = (f"Live Cards Found: {live_item_count}\n"
                           f"Charge Cards Found: {charge_item_count}")
                await message.reply_document(document=file, caption=caption)

            os.remove(temp_file_path)
            env_var_name = f"LIVE_AND_CHARGE_CARDS_FILE_{unique_id}"

            if os.getenv(env_var_name):
                del os.environ[env_var_name]

        else:
            await message.reply_text(f"__No Live {item_type.replace('_', ' ')} found__")


    elif unique_id_full.startswith("sktxt_"):
        unique_id = unique_id_full.replace("sktxt_", "")
        temp_file_path = os.getenv(f'LIVE_SK_KEYS_FILE_{unique_id}')
        item_type = 'sk_key'

        if temp_file_path and os.path.exists(temp_file_path):

            if os.path.getsize(temp_file_path) == 0:
                await message.reply("The live items file is empty. No live items found.")
                os.remove(temp_file_path)
                return

            with open(temp_file_path, 'r') as file:
                for line in file:
                    if sk_key_pattern.search(line):
                        live_item_count += 1

            with open(temp_file_path, 'rb') as file:
                caption = f"Live SK Keys Found: {live_item_count}"
                await message.reply_document(document=file, caption=caption)

            os.remove(temp_file_path)
            env_var_name = f"LIVE_SK_KEYS_FILE_{unique_id}"

            if os.getenv(env_var_name):
                del os.environ[env_var_name]

        else:
            await message.reply_text(f"__No Live {item_type.replace('_', ' ')} found__")
