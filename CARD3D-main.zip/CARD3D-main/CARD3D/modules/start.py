from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery, Message
from pyrogram.enums import ParseMode
from CARD3D import app, BOT_USERNAME, BOT_NAME
from CARD3D.core.mongo import get_user, LEVELS
from config import OWNER_ID
import CARD3D.core.mongo as mongo

def format_datetime(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S UTC") if dt else "N/A"

async def create_or_get_user(user_id, user_name):
    try:
        user = await mongo.get_user(user_id)
        if not user:
            user = await mongo.create_user(user_id, user_name)
        return user, None
    except Exception as e:
        return None, f"Error fetching or creating user: {str(e)}"

START_TEXT = """
**ʜᴇʏ** {},
ɪ ᴀᴍ [{bot_name}](https://t.me/{bot_username}), ᴀɴ ᴀᴅᴠᴀɴᴄᴇᴅ ᴀɪ-ʙᴀsᴇᴅ ʀᴏʙᴏᴛ ᴅᴇsɪɢɴᴇᴅ ᴛᴏ ᴘᴇʀғᴏʀᴍ ᴠᴀʀɪᴏᴜs ᴛᴀsᴋs ᴇғғᴏʀᴛʟᴇssʟʏ.

ᴇxᴘʟᴏʀᴇ ᴍʏ ᴄᴏᴍᴍᴀɴᴅs ᴍᴇɴᴜ ᴛᴏ ᴅɪsᴄᴏᴠᴇʀ ᴍᴏʀᴇ ᴀʙᴏᴜᴛ ᴍʏ ᴄᴀᴘᴀʙɪʟɪᴛɪᴇs ᴀɴᴅ ʜᴏᴡ ʏᴏᴜ ᴄᴀɴ ɪɴᴛᴇʀᴀᴄᴛ ᴡɪᴛʜ ᴍᴇ.
"""

REGISTER_TEXT = "**ᴘʟᴇᴀsᴇ ʀᴇɢɪsᴛᴇʀ ᴜsɪɴɢ /register ᴛᴏ sᴛᴀʀᴛ ᴜsɪɴɢ ᴛʜᴇ ʙᴏᴛ.**"

CHK_TXT = """
Hello User!

[˹Ꮯᴀʀᴅ˼˹3Ꭰ˼](https://t.me/CARD3DBOT) Checker Gates.

Click on each one below to get to know them better.
"""

NISHKA_TXT = """
**Hello User!**

[˹Ꮯᴀʀᴅ˼˹3Ꭰ˼](https://t.me/CARD3DBOT) **Nishika Coming Soon**.

**Use** /premium **to know more about premium features.**
"""

AUTH_TXT = """
Hello User!

[˹Ꮯᴀʀᴅ˼˹3Ꭰ˼ ](https://t.me/CARD3DBOT) Auth Gates.

Click on each one below to get to know them better.
"""

CHARGE_TXT = """
Hello User!

[˹Ꮯᴀʀᴅ˼˹3Ꭰ˼](https://t.me/CARD3DBOT) Charge Gates.

Click on each one below to get to know them better.
"""

LOOKUP_TXT = """
**Lookup Commands 🔍**
━━━━━━━━━━━━━━━
Status: **Active** ✅

➥ /bin : Retrieve BIN information.
➥ /gate : Inspect payment gateways.
➥ /sk : Check SK status (live or dead).
➥ /msk : Mass SK status check.
➥ /sktxt : Mass SK status check from a document.
➥ /proxy : Check a proxy's live status.
➥ /proxytxt : Check proxies' live status from a document.
➥ /chkip : Inspect IP information.
"""

TOOL_TXT = """
**Toolkit Commands 🛠**
━━━━━━━━━━━━━━━
Status: **Active** ✅

➥ /gen : Generate CCs using a 6-digit BIN [LUHAN ALGORITHM].
➥ /fake : Get a random address from a specific country (use country code).
➥ /scr : Scrape CCs from a channel or group.
➥ /skscr : Scrape SKs from a channel or group.
➥ /proxyscr : Scrape proxies from a channel or group.
➥ /ipgen : Generate a specified number of IP addresses.
➥ /txt : Convert replied text to a document.
➥ /fl or /clean : Clean CCs, proxies, and SKs from a file.
➥ /split : Split a file or input into specified parts.
"""

HELP_TXT = """
**Bot Status:** Active ✅

Hello User! [˹Ꮯᴀʀᴅ˼˹3Ꭰ˼ ](https://t.me/CARD3DBOT) offers plenty of commands, including Auth Gates, Charge Gates, Tools, and other features.

Click each of them below to know more.
"""

EXTRA_TXT = """
**Additional Features:**
━━━━━━━━━━━━━━━
Status: **Active** ✅

➥ /upscale : Upscale an image.
➥ /getdraw : Generate an image.
➥ /mongochk : Verify a MongoDB URL.
➥ /insta : Download Instagram reels.
➥ /webss : Take a screenshot of a webpage.
➥ /rmbg : Remove the background from an image.
➥ /pypi : Check the version of a PyPI package.
➥ /domain : Get domain information.
➥ /gps : Retrieve GPS coordinates.
"""

STRIPESITE_TXT = """
**Stripe Site-Based Charge Gate**
━━━━━━━━━━━━━━━
Status: **Active** ✅

1. Charge $5
   ➜ Single: `/svv cc|mm|yy|cvv`
   ➜ Mass (Limit = 5): `/msvv cc|mm|yy|cvv`
"""

BCHARGE_TXT = """
**Braintree Charge Gate**
━━━━━━━━━━━━━━━
Status: Inactive ❌

1. Charge £1
   ➜ Single: `/br cc|mm|yy|cvv`
   ➜ Mass (Limit = 5): `/mbr cc|mm|yy|cvv`
"""

SKCHARGE_TXT = """
**SK-Based Payment Gates**
━━━━━━━━━━━━━━━━━
Status: **Active** ✅

1. **$1 Charge (CVV-Based)**
   ➜ **Single Charge**: Use `/xvv cc|mm|yy|cvv`
   ➜ **Mass Charge** : Use `/xxvv cc|mm|yy|cvv`
   ➜ **Mass Charge from Text File**: Reply to a file with `/xvvtxt`
"""


B3AUTH_TXT = """
**Braintree Auth**
━━━━━━━━━━━━━━━
Status: Inactive ❌

1. Braintree B3 Auth
   ➜ Single: `/ba cc|mm|yy|cvv`
   ➜ Mass (Limit = 5): `/mba cc|mm|yy|cvv`
"""

STAUTH_TXT = """
**Stripe Auth**
━━━━━━━━━━━━━━━
Status: **Active** ✅

1. Stripe Auth
   ➜ Single: `/sa cc|mm|yy|cvv`
   ➜ Mass : `/msa cc|mm|yy|cvv`
"""

VBV_TXT = """
**Braintree VBV**
━━━━━━━━━━━━━━━
Status: **Active** ✅

1. VBV Lookup
   ➜ Single: `/vbv cc|mm|yy|cvv`
   ➜ Mass (Limit = 6): `/mvbv cc|mm|yy|cvv`
"""

def create_button(text, callback_data):
    return InlineKeyboardButton(text, callback_data=callback_data)

def create_markup(buttons):
    return InlineKeyboardMarkup(buttons)

def get_home_buttons():
    return create_markup([[create_button("Menu 🔎", "help_")]])

def get_back_button():
    return create_markup([[create_button("Go Back ◀️", "help_")]])

def get_checker_buttons():
    return create_markup([
        [create_button("Auth", "auth_"), create_button("Charge", "charge_")],
        [create_button("VBV", "vbv_")],
        [create_button("Go Back ◀️", "help_"), create_button("Terminate🔁", "close_")]
    ])

def get_auth_buttons():
    return create_markup([
        [create_button("Stripe", "stripeauth_"), create_button("Braintree", "braintreeauth_")],
        [create_button("Go Back ◀️", "checker_"), create_button("Terminate🔁", "close_")]
    ])

def get_charge_buttons():
    return create_markup([
        [create_button("Stripe", "stripesite_"), create_button("Braintree", "b3site_")],
        [create_button("SK Based", "skbased_")],
        [create_button("Go Back ◀️", "checker_"), create_button("Terminate🔁", "close_")]
    ])

def get_help_buttons():
    return create_markup([
        [create_button("Checker", "checker_"), create_button("Lookup", "lookup_")],
        [create_button("Toolkit", "tool_")],
        [create_button("Nishka", "credits_"), create_button("Extra", "extra_")],
        [create_button("Terminate🔁", "close_")]
    ])

def get_specific_back_button(callback_data):
    return create_markup([[create_button("Go Back ◀️", callback_data)]])

@app.on_message(filters.command("start") & filters.private)
async def start_command(client, message):
    user = await mongo.get_user(message.from_user.id)
    if user:
        await message.reply_video(
            video="https://telegra.ph/file/19054d4deea2e1f4f2c97.mp4",
            caption=START_TEXT.format(
                message.from_user.mention, bot_name=BOT_NAME, bot_username=BOT_USERNAME
            ),
            reply_markup=get_home_buttons(),
        )
    else:
        await message.reply_text(REGISTER_TEXT, disable_web_page_preview=True)

@app.on_message(filters.command("register") & filters.private)
async def register_command(client: Client, message: Message):
    user = await mongo.get_user(message.from_user.id)
    if user:
        await message.reply_text("✅ **You are already registered! There's no need to register again.**", disable_web_page_preview=True)
    else:
        await mongo.create_user(message.from_user.id, message.from_user.first_name)
        await message.reply_text(
            "✅ **Registration complete! You are now a Free User and can use the bot in the support chat.**", 
            disable_web_page_preview=True
        )

@app.on_message(filters.command("register") & ~filters.private)
async def register_in_group(client: Client, message: Message):
    user = await mongo.get_user(message.from_user.id)
    if user:
        await message.reply_text(
            "✅ **You are already registered! There's no need to register again.**",
            disable_web_page_preview=True
        )
    else:
        await message.reply_text(
            "❌ **Registration can only be done in private chat with the bot. Please send /register in the bot's private chat.**",
            disable_web_page_preview=True
        )

@app.on_message(filters.command("cmds"))
async def help_command(client, message):
    user = await mongo.get_user(message.from_user.id)
    if not user:
        await message.reply_text(REGISTER_TEXT, disable_web_page_preview=True)
        return
    await message.reply_text(HELP_TXT, reply_markup=get_help_buttons(), disable_web_page_preview=True)

@app.on_message(filters.command("info"))
async def info_command(client, message):
    owner_id = OWNER_ID
    if message.reply_to_message:
        target_user_id = message.reply_to_message.from_user.id
    elif len(message.command) == 2:
        try:
            target_user_id = int(message.command[1])
        except ValueError:
            return await message.reply_text("Invalid ID format provided.", disable_web_page_preview=True)
    else:
        target_user_id = message.from_user.id
    user = await get_user(target_user_id)
    if user:
        credits = user.get("credits", 0)
        status = user.get("status", "NORMAL")
        plan = user.get("plan", "N/A")
        plan_start = user.get("plan_start", "N/A")
        plan_end = user.get("plan_end", "N/A")
        if target_user_id == owner_id:
            credits = "♾️"
            plan = "STRIPEHIT"
            plan_start = "♾️"
            plan_end = "♾️"
            status = "PREMIUM"
        if plan in LEVELS:
            plan_info = f"{plan} ({LEVELS[plan]['symbol']}) - {LEVELS[plan]['credits']} daily credits"
        else:
            plan_info = "N/A"
        reply_text = (
            f"𝖸𝗈𝗎𝗋 𝖨𝗇𝖿𝗈 𝗈𝗇 ˹Ꮯᴀʀᴅ˼˹3Ꭰ˼ 𐏓\n━━━━━━━━━━━━━━\n"
            f"**𝖭𝖺𝗆𝖾:** {user['name']}\n"
            f"**𝖨𝖣:** `{target_user_id}`\n"
            f"**𝖢𝗋𝖾𝖽𝗂𝗍𝗌:** {credits}\n"
            f"**𝖲𝗍𝖺𝗍𝗎𝗌:** {status}\n"
            f"**𝖯𝗅𝖺𝗇:** {plan_info}\n"
            f"**𝖯𝗅𝖺𝗇 𝖲𝗍𝖺𝗋𝗍:** {plan_start}\n"
            f"**𝖯𝗅𝖺𝗇 𝖤𝗑𝗉𝗂𝗋𝗒:** {plan_end}\n"
        )
        await message.reply_text(reply_text, parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True)
    else:
        await message.reply_text("User is not registered. Please use /register.", parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True)

@app.on_message(filters.command('id'))
async def getid(client, message):
    chat = message.chat
    your_id = message.from_user.id
    message_id = message.id
    reply = message.reply_to_message
    text = f"**[ᴍᴇssᴀɢᴇ ɪᴅ:]({message.link})** `{message_id}`\n"
    text += f"**[ʏᴏᴜʀ ɪᴅ:](tg://user?id={your_id})** `{your_id}`\n"
    if len(message.command) == 2:
        try:
            user_to_fetch = message.text.split(None, 1)[1].strip()
            fetched_user = await client.get_users(user_to_fetch)
            text += f"**[ᴜsᴇʀ ɪᴅ:](tg://user?id={fetched_user.id})** `{fetched_user.id}`\n"
        except Exception:
            return await message.reply_text("ᴛʜɪs ᴜsᴇʀ ᴅᴏᴇsɴ'ᴛ ᴇxɪsᴛ.", quote=True, disable_web_page_preview=True)
    text += f"**[ᴄʜᴀᴛ ɪᴅ:](https://t.me/{chat.username})** `{chat.id}`\n\n"
    if reply:
        text += f"**[ʀᴇᴘʟɪᴇᴅ ᴍᴇssᴀɢᴇ ɪᴅ:]({reply.link})** `{reply.id}`\n"
        text += f"**[ʀᴇᴘʟɪᴇᴅ ᴜsᴇʀ ɪᴅ:](tg://user?id={reply.from_user.id})** `{reply.from_user.id}`\n\n"
        if reply.forward_from_chat:
            text += f"ᴛʜᴇ ғᴏʀᴡᴀʀᴅᴇᴅ ᴄʜᴀɴɴᴇʟ, {reply.forward_from_chat.title}, ʜᴀs ᴀɴ ɪᴅ ᴏғ `{reply.forward_from_chat.id}`\n\n"
        if reply.sender_chat:
            text += f"ɪᴅ ᴏғ ᴛʜᴇ ʀᴇᴘʟɪᴇᴅ ᴄʜᴀᴛ/ᴄʜᴀɴɴᴇʟ, ɪs `{reply.sender_chat.id}`"
    await message.reply_text(
        text, 
        disable_web_page_preview=True, 
        parse_mode=ParseMode.MARKDOWN
    )

@app.on_callback_query()
async def callback_handler(client, query: CallbackQuery):
    callback_data = query.data
    if callback_data == "close_":
        await query.message.delete()
        await query.message.reply_text("Enjoy 𐏓 @TheCARD3DRobot", disable_web_page_preview=True)
    else:
        text, markup = get_callback_response(query)
        await query.message.edit_text(text, reply_markup=markup, disable_web_page_preview=True)

def get_callback_response(query: CallbackQuery):
    callback_data = query.data
    user_mention = query.from_user.mention
    response_map = {
        "home_": (
            START_TEXT.format(user_mention, bot_name=BOT_NAME, bot_username=BOT_USERNAME),
            get_home_buttons()
        ),
        "help_": (HELP_TXT, get_help_buttons()),
        "checker_": (CHK_TXT, get_checker_buttons()),
        "auth_": (AUTH_TXT, get_auth_buttons()),
        "charge_": (CHARGE_TXT, get_charge_buttons()),
        "lookup_": (LOOKUP_TXT, get_back_button()),
        "credits_": (NISHKA_TXT, get_back_button()),
        "extra_": (EXTRA_TXT, get_back_button()),
        "tool_": (TOOL_TXT, get_back_button()),
        "vbv_": (VBV_TXT, get_specific_back_button("checker_")),
        "stripeauth_": (STAUTH_TXT, get_specific_back_button("auth_")),
        "braintreeauth_": (B3AUTH_TXT, get_specific_back_button("auth_")),
        "skbased_": (SKCHARGE_TXT, get_specific_back_button("charge_")),
        "b3site_": (BCHARGE_TXT, get_specific_back_button("charge_")),
        "stripesite_": (STRIPESITE_TXT, get_specific_back_button("charge_")),
    }
    return response_map.get(callback_data, (HELP_TXT, get_help_buttons()))
