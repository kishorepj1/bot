import asyncio
import aiohttp
import logging
from pyrogram import Client, filters
from pyrogram.types import Message
from CARD3D import app
from config import OWNER_ID
from CARD3D.core.mongo import has_premium_access, get_user, update_user, LEVELS
from pyrogram.enums import ParseMode


async def check_proxy(proxy):
    url = "http://httpbin.org/ip"
    try:
        proxy_parts = proxy.split(":")
        proxy_auth = aiohttp.BasicAuth(*proxy_parts[2:]) if len(proxy_parts) == 4 else None
        proxy_url = f"http://{proxy_parts[0]}:{proxy_parts[1]}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, proxy=proxy_url, proxy_auth=proxy_auth, timeout=5) as response:
                return proxy, "Live ✅" if response.status == 200 else "Dead ❌"
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        return proxy, "Dead ❌"

@app.on_message(filters.command("proxy"))
async def single_proxy_handler(client: Client, message: Message):
    user_id = message.from_user.id
    chat_id = message.chat.id

    has_access, access_msg, user_plan = await has_premium_access(user_id, chat_id, required_credits=0)
    if not has_access:
        await message.reply_text(access_msg, parse_mode=ParseMode.MARKDOWN)
        return

    user = await get_user(user_id)
    if not user:
        await message.reply_text("❌ **You are not registered. Please register using  /register in private.**", parse_mode=ParseMode.MARKDOWN)
        return

    user_plan = user.get("plan", "Free")
    user_credits = user.get("credits", 0)
    user_plan_symbol = LEVELS.get(user_plan, {}).get('symbol', '')

    if user_id == OWNER_ID:
        user_plan = "STRIPEHIT"
        user_plan_symbol = LEVELS["STRIPEHIT"]["symbol"]
        user_credits = -1

    if len(message.command) < 2:
        await message.reply("Usage: `/proxy ip:port:username:password`")
        return

    proxies = message.command[1:]
    user_id = message.from_user.id

    tasks = [check_proxy(proxy) for proxy in proxies]
    results = await asyncio.gather(*tasks)

    proxy_responses = "\n".join([f"`{proxy}`\nResponse ➜ **{result}**" for proxy, result in results])

    final_message = f"""
┏━━━━━━━⍟
┃𝗣𝗿𝗼𝘅𝘆 𝗖𝗵𝗲𝗰𝗸𝗲𝗿 ✅
┗━━━━━━━━━━━━━━⊛

{proxy_responses}

Checked by ➜ {message.from_user.mention} ⤿ {user_plan} {user_plan_symbol} ⤾
"""
    await message.reply(final_message)

    if user_id != OWNER_ID:
                new_credits = user_credits - 1
    await update_user(user_id, {"credits": new_credits})
