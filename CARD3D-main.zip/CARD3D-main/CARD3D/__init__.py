import logging
import asyncio
from dotenv import load_dotenv
from pyrogram import Client
from importlib import import_module
from os import listdir, path
from config import API_ID, API_HASH, BOT_TOKEN, STRING

load_dotenv()

logging.basicConfig(
    format="[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s",
    level=logging.INFO,
)

app = Client(
    ":CARD3D:",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
)
userbot = Client(
    name="CARD3D Userbot",
    api_id=API_ID,
    api_hash=API_HASH,
    session_string=STRING,
    no_updates=True,
)

loop = asyncio.get_event_loop()


async def info_bot():
    global BOT_ID, BOT_NAME, BOT_USERNAME

    await app.start()
    await userbot.start()

    getme = await app.get_me()
    BOT_ID = getme.id
    BOT_USERNAME = getme.username

    BOT_NAME = (
        f"{getme.first_name} {getme.last_name}" if getme.last_name else getme.first_name
    )


loop.run_until_complete(info_bot())
