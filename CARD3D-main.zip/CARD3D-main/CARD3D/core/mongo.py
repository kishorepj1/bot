import motor.motor_asyncio
from config import MONGO_URL, OWNER_ID, SUPPORT_CHAT_LINK, LOGGER_ID 
from datetime import datetime, timedelta
import pytz
import pymongo
import asyncio
from collections import defaultdict
from CARD3D import app
import random
import string

try:
    mongo_client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
    db = mongo_client["my_database"]
    users_collection = db["users"]
    authorized_groups_collection = db["authorized_groups"]
    redeem_codes_collection = db["redeem_codes"]
    users_collection.create_index([("user_id", 1)], unique=True)
    redeem_codes_collection.create_index([("code", 1)], unique=True)
    print("✅ Connected to MongoDB successfully.")
except Exception as e:
    print(f"❌ Failed to connect to MongoDB: {e}")
    raise e

IST = pytz.timezone("Asia/Kolkata")

LEVELS = {
    "Free": {"symbol": "🆓", "credits": 0, "daily_credits": 0, "duration_days": None, "price": 0},
    "Bronze": {"symbol": "🥉", "credits": 1500, "daily_credits": 1500, "duration_days": 1, "price": 3},
    "Silver": {"symbol": "🥈", "credits": 3000, "daily_credits": 3000, "duration_days": 3, "price": 7},
    "Gold": {"symbol": "🥇", "credits": 5000, "daily_credits": 5000, "duration_days": 7, "price": 15},
    "Platinum": {"symbol": "🔮", "credits": 8000, "daily_credits": 8000, "duration_days": 15, "price": 25},
    "Diamond": {"symbol": "💎", "credits": 10000, "daily_credits": 10000, "duration_days": 30, "price": 40},
    "STRIPEHIT": {"symbol": "💠", "credits": -1, "daily_credits": -1, "duration_days": None, "price": "♾️"},
}

user_cache = defaultdict(dict)
user_locks = defaultdict(asyncio.Lock)

SUPPORT_CHAT_ID = -1002385181356


#................................................[User Ensure].....................................................

async def get_user(user_id):
    if int(user_id) == int(OWNER_ID):
        return {
            "user_id": OWNER_ID,
            "name": "Owner",
            "credits": -1,
            "status": "PREMIUM",
            "plan": "STRIPEHIT",
            "plan_start": None,
            "plan_end": None
        }

    if user_id in user_cache:
        return user_cache[user_id]

    try:
        user = await users_collection.find_one({"user_id": user_id})
        if user:
            user_cache[user_id] = user
        return user
    except Exception as e:
        print(f"Error fetching user {user_id}: {e}")
        return None

async def ensure_owner_registration():
    user = await get_user(OWNER_ID)
    if not user:
        await create_user(OWNER_ID, "Owner")
    await update_user(
        OWNER_ID,
        {
            "status": "PREMIUM",
            "plan": "STRIPEHIT",
            "credits": -1,
            "plan_start": None,
            "plan_end": None,
        },
    )
    print(f"✅ Registered OWNER_ID with STRIPEHIT plan.")

async def create_user(user_id, name):
    if int(user_id) == int(OWNER_ID):
        return await ensure_owner_registration()

    user = {
        "user_id": user_id,
        "name": name,
        "credits": LEVELS["Free"]["credits"],
        "status": "FREE",
        "plan": "Free",
        "plan_start": datetime.now(IST),
        "plan_end": None,
    }
    try:
        await users_collection.insert_one(user)
        user_cache[user_id] = user
        print(f"✅ Created new user: {user_id} - {name}")
        await send_logger_message(f"✅ Created new user: {user_id} - {name}")
        return user
    except Exception as e:
        print(f"Error creating user {user_id}: {e}")
        return None

async def update_user(user_id, update_fields):
    if int(user_id) == int(OWNER_ID):
        return True

    async with user_locks[user_id]:
        try:
            result = await users_collection.update_one(
                {"user_id": user_id}, {"$set": update_fields}
            )
            if result.matched_count:
                user = await get_user(user_id)
                if user:
                    user.update(update_fields)
                    user_cache[user_id] = user
                print(f"✅ Updated user {user_id} with fields {update_fields}")
                await send_logger_message(f"✅ Updated user {user_id} with fields {update_fields}")
                return True
            else:
                print(f"⚠️ User {user_id} not found for update.")
                return False
        except Exception as e:
            print(f"Error updating user {user_id}: {e}")
            return False


#................................................[User Done].....................................................


#................................................[Group Auth Start]...........................................................

async def authorize_group(chat_id, chat_title, broadcast_enabled=False):
    try:
        await authorized_groups_collection.update_one(
            {"chat_id": chat_id},
            {"$set": {"chat_title": chat_title, "broadcast_enabled": broadcast_enabled}},
            upsert=True
        )
        print(f"✅ Authorized group {chat_title} (ID: {chat_id}).")
        await send_logger_message(f"✅ Authorized group {chat_title} (ID: {chat_id}). Broadcast Enabled: {broadcast_enabled}")
        return True
    except Exception as e:
        print(f"Error authorizing group {chat_id}: {e}")
        return False

async def is_group_authorized(chat_id):
    try:
        result = await authorized_groups_collection.find_one({"chat_id": chat_id})
        return result is not None
    except Exception as e:
        print(f"Error checking group authorization for {chat_id}: {e}")
        return False

async def remove_group_authorization(chat_id):
    try:
        result = await authorized_groups_collection.delete_one({"chat_id": chat_id})
        if result.deleted_count > 0:
            print(f"✅ Removed authorization for group ID {chat_id}.")
            await send_logger_message(f"✅ Removed authorization for group ID {chat_id}.")
            return True
        else:
            print(f"⚠️ Group ID {chat_id} was not authorized.")
            return False
    except Exception as e:
        print(f"Error removing group authorization for {chat_id}: {e}")
        return False

async def get_all_authorized_groups():
    try:
        groups = authorized_groups_collection.find()
        return [group async for group in groups]
    except Exception as e:
        print(f"Error fetching authorized groups: {e}")
        return []

#................................................[Group Auth End].........................................................


#................................................[Broadcast]...............................................................

async def get_all_user_ids():
    try:
        users = await users_collection.find({}, {"user_id": 1}).to_list(length=None)
        user_ids = [user["user_id"] for user in users]
        return user_ids
    except Exception as e:
        print(f"Error fetching user IDs: {e}")
        return []

async def get_all_broadcast_chats():
    try:
        chats = await authorized_groups_collection.find({"broadcast_enabled": True}).to_list(length=None)
        chat_ids = [chat["chat_id"] for chat in chats]
        return chat_ids
    except Exception as e:
        print(f"Error fetching broadcast chats: {e}")
        return []


#................................................[Broadcast End]...............................................................


#................................................[Credits System Start].....................................................

async def add_credits(user_id, amount):
    if int(user_id) == int(OWNER_ID):
        return -1

    user = await get_user(user_id)
    if user:
        try:
            new_credits = user.get("credits", 0) + amount
            await update_user(user_id, {"credits": new_credits})
            await update_user_plan_by_credits(user_id, new_credits)
            await send_logger_message(f"✅ Added {amount} credits to user {user_id}. New balance: {new_credits}")
            return new_credits
        except Exception as e:
            print(f"Error adding credits to user {user_id}: {e}")
    else:
        print(f"User {user_id} not found when attempting to add credits.")
    return None

async def remove_credits(user_id, amount):
    if int(user_id) == int(OWNER_ID):
        return -1

    user = await get_user(user_id)
    if user and user.get("credits") != -1:
        try:
            new_credits = max(user.get("credits", 0) - amount, 0)
            await update_user(user_id, {"credits": new_credits})
            await update_user_plan_by_credits(user_id, new_credits)
            await send_logger_message(f"✅ Removed {amount} credits from user {user_id}. New balance: {new_credits}")
            return new_credits
        except Exception as e:
            print(f"Error removing credits from user {user_id}: {e}")
    return None

async def update_user_plan_by_credits(user_id, new_credits):
    if int(user_id) == int(OWNER_ID):
        return

    user = await get_user(user_id)
    if user:
        current_plan = user.get("plan", "N/A")
        best_plan_name = None

        for level, details in sorted(LEVELS.items(), key=lambda x: x[1]["credits"], reverse=True):
            if (
                isinstance(details["credits"], int)
                and new_credits >= details["credits"]
                and level != "STRIPEHIT"
            ):
                best_plan_name = level
                break

        if best_plan_name and best_plan_name != current_plan:
            plan_start = datetime.now(IST)
            plan_end = (
                plan_start + timedelta(days=LEVELS[best_plan_name]["duration_days"])
                if LEVELS[best_plan_name]["duration_days"]
                else None
            )
            await update_user(
                user_id,
                {
                    "plan": best_plan_name,
                    "status": "PREMIUM" if best_plan_name != "Free" else "FREE",
                    "plan_start": plan_start,
                    "plan_end": plan_end,
                },
            )
            print(f"User {user_id} upgraded to {best_plan_name} plan.")
            await send_logger_message(f"User {user_id} upgraded to {best_plan_name} plan.")
        elif not best_plan_name and current_plan != "Free":
            await update_user(
                user_id,
                {
                    "plan": "Free",
                    "status": "FREE",
                    "plan_start": datetime.now(IST),
                    "plan_end": None,
                },
            )
            print(f"User {user_id} downgraded to FREE plan.")
            await send_logger_message(f"User {user_id} downgraded to FREE plan.")

async def set_user_plan(user_id, plan_name):
    plan = LEVELS.get(plan_name)
    if not plan:
        print(f"Plan {plan_name} does not exist.")
        return False

    plan_start = datetime.now(IST)
    plan_end = plan_start + timedelta(days=plan["duration_days"]) if plan["duration_days"] else None
    credits = plan["credits"]
    update_fields = {
        "status": "PREMIUM" if plan_name != "Free" else "FREE",
        "plan": plan_name,
        "credits": credits,
        "plan_start": plan_start,
        "plan_end": plan_end,
    }
    try:
        success = await update_user(user_id, update_fields)
        if success:
            print(f"✅ Set plan {plan_name} for user {user_id}.")
            await send_logger_message(f"✅ Set plan {plan_name} for user {user_id}.")
            return True
    except Exception as e:
        print(f"Error setting plan for user {user_id}: {e}")
    return False

async def check_plan_expiry(user_id):
    if int(user_id) == int(OWNER_ID):
        return False
    user = await get_user(user_id)
    if user and user.get("plan_end"):
        plan_end = user["plan_end"]
        if plan_end.tzinfo is None:
            plan_end = IST.localize(plan_end)
        if datetime.now(IST) >= plan_end:
            update_fields = {
                "status": "FREE",
                "plan": "Free",
                "credits": LEVELS["Free"]["credits"],
                "plan_start": datetime.now(IST),
                "plan_end": None,
            }
            success = await update_user(user_id, update_fields)
            if success:
                print(f"⚠️ Plan expired for user {user_id}. Downgraded to FREE plan.")
                await send_logger_message(f"⚠️ Plan expired for user {user_id}. Downgraded to FREE plan.")
                return True
    return False

async def reset_all_daily_credits():
    try:
        active_users = await users_collection.find(
            {"status": {"$in": ["PREMIUM", "FREE"]}}
        ).to_list(length=None)

        bulk_operations = []
        for user in active_users:
            user_id = user["user_id"]
            if int(user_id) == int(OWNER_ID):
                continue
            if user["status"] == "PREMIUM":
                if await check_plan_expiry(user_id):
                    continue
            plan_name = user["plan"]
            daily_credits = LEVELS[plan_name]["daily_credits"]
            if daily_credits != -1:
                bulk_operations.append(
                    pymongo.UpdateOne(
                        {"user_id": user_id}, {"$set": {"credits": daily_credits}}
                    )
                )
            else:
                bulk_operations.append(
                    pymongo.UpdateOne(
                        {"user_id": user_id}, {"$set": {"credits": -1}}
                    )
                )

        if bulk_operations:
            result = await users_collection.bulk_write(bulk_operations)
            print(f"📈 Reset daily credits for {result.matched_count} users.")
            await send_logger_message(f"📈 Reset daily credits for {result.matched_count} users.")
    except Exception as e:
        print(f"Error resetting daily credits: {e}")

async def reset_daily_credits(user_id):
    user = await get_user(user_id)
    if user and user.get("status") in ["PREMIUM", "FREE"]:
        plan_name = user.get("plan")
        if plan_name in LEVELS:
            daily_credits = LEVELS[plan_name]["daily_credits"]
            await update_user(user_id, {"credits": daily_credits})
            print(f"Daily credits reset to {daily_credits} for user {user_id}.")
            await send_logger_message(f"Daily credits reset to {daily_credits} for user {user_id}.")

async def reset_all_credits():
    try:
        users = await users_collection.find({}).to_list(length=None)
        bulk_operations = []
        for user in users:
            user_id = user["user_id"]
            plan_name = user.get("plan", "Free")
            if plan_name not in LEVELS:
                print(f"⚠️ User {user_id} has an invalid plan '{plan_name}'. Defaulting to 'Free'.")
                plan_name = "Free"
                await update_user(user_id, {"plan": "Free", "status": "FREE"})
            daily_credits = LEVELS[plan_name]["daily_credits"]
            new_credits = daily_credits if daily_credits != -1 else -1
            bulk_operations.append(
                pymongo.UpdateOne(
                    {"user_id": user_id}, {"$set": {"credits": new_credits}}
                )
            )
        if bulk_operations:
            result = await users_collection.bulk_write(bulk_operations)
            print(f"📈 Reset credits for {result.matched_count} users.")
            await send_logger_message(f"📈 Reset credits for {result.matched_count} users.")
    except Exception as e:
        print(f"Error resetting credits: {type(e).__name__}: {e}")

#................................................[Credits System End].....................................................

#................................................[Redeem Code Functions].....................................................

async def generate_redeem_codes(plan_name, amount, prefix="CARD3D"):
    codes = []
    prefix = prefix.upper()  
    for _ in range(amount):
        while True:

            code_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))

            code = f"{prefix}-{code_part}"
            existing_code = await redeem_codes_collection.find_one({"code": code})
            if not existing_code:
                break
        redeem_code = {
            "code": code,
            "plan_name": plan_name,
            "redeemed_by": None,
            "redeemed_at": None,
            "created_at": datetime.now(IST),
            "is_redeemed": False,
        }
        try:
            await redeem_codes_collection.insert_one(redeem_code)
            codes.append(code)
        except Exception as e:
            print(f"Error generating redeem code: {e}")
    return codes

async def redeem_code(user_id, code):
    code_info = await redeem_codes_collection.find_one({"code": code})
    if not code_info:
        return False, "❌ Invalid code.", None

    if code_info.get("is_redeemed", False):
        return False, "❌ This code has already been redeemed.", None

    plan_name = code_info.get("plan_name")
    if plan_name not in LEVELS:
        return False, "❌ Invalid plan associated with this code.", None


    await redeem_codes_collection.update_one(
        {"code": code},
        {
            "$set": {
                "is_redeemed": True,
                "redeemed_by": user_id,
                "redeemed_at": datetime.now(IST),
            }
        }
    )

    success = await set_user_plan(user_id, plan_name)
    if success:
        return True, f"🎉 Successfully redeemed code. Your plan has been updated to **{plan_name}**.", plan_name
    else:
        return False, "❌ Failed to update your plan. Please contact support.", None

#................................................[Redeem Code Functions End].....................................................

#................................................[Premium Check Of users ]....................................................

async def has_premium_access(user_id, chat_id, required_credits=0):
    if int(user_id) == int(OWNER_ID):
        return True, None, f"STRIPEHIT {LEVELS['STRIPEHIT']['symbol']}"

    user = await get_user(user_id)
    if not user:
        return (
            False,
            "❌ **User not registered. Please register first using /register.**",
            "N/A",
        )

    plan_name = user.get("plan", "Free")
    plan_with_symbol = f"{plan_name} {LEVELS.get(plan_name, {}).get('symbol', '')}"

    if user["status"] == "FREE":
        if chat_id != SUPPORT_CHAT_ID and not await is_group_authorized(chat_id):
            return (
                False,
                f"⚠️ **Free users can only use this command in the [Support Chat]({SUPPORT_CHAT_LINK}) or Authorized groups.**",
                plan_with_symbol,
            )
        user_credits = user.get("credits", 0)
        if user_credits >= required_credits:
            return True, None, plan_with_symbol
        else:
            return (
                False,
                "❌ **Insufficient credits. Please wait for the daily reset or upgrade your plan.**",
                plan_with_symbol,
            )

    if user["status"] != "PREMIUM":
        return (
            False,
            "❌ **This command requires premium privileges.**\nUse /premium to view available plans and buy premium access.",
            "N/A",
        )

    if await check_plan_expiry(user_id):
        return (
            False,
            "⚠️ **Your premium plan has expired. Please purchase a new plan to continue.**",
            "N/A",
        )

    user_credits = user.get("credits", 0)

    if user_credits == -1:
        return True, None, plan_with_symbol

    if user_credits >= required_credits:
        return True, None, plan_with_symbol
    else:
        return (
            False,
            "❌ **Insufficient credits for today. Please wait for the daily reset or upgrade your plan.**",
            plan_with_symbol,
        )

async def get_premium_users():
    try:
        return [
            user async for user in users_collection.find({"status": "PREMIUM"})
        ]
    except Exception as e:
        print(f"Error fetching premium users: {e}")
        return []

async def remove_all_premium_users():
    try:
        result = await users_collection.update_many(
            {"status": "PREMIUM", "user_id": {"$ne": OWNER_ID}},
            {
                "$set": {
                    "status": "FREE",
                    "plan": "Free",
                    "credits": LEVELS["Free"]["credits"],
                    "plan_start": datetime.now(IST),
                    "plan_end": None,
                }
            },
        )
        print(f"✅ Removed premium status from {result.modified_count} users.")
        await send_logger_message(f"✅ Removed premium status from {result.modified_count} users.")
        return result.modified_count
    except Exception as e:
        print(f"Error removing premium users: {e}")
        return 0

async def get_all_users():
    try:
        users = await users_collection.find({}).to_list(length=None)
        return users
    except Exception as e:
        print(f"Error fetching all users: {e}")
        return []

#................................................[Premium Check Of users End].....................................................


#................................................[Logger Function].......................................................

async def send_logger_message(message_text):
    try:
        await app.send_message(chat_id=LOGGER_ID, text=message_text)
    except Exception as e:
        print(f"Error sending log message: {e}")

#................................................[Logger Function End].......................................................


#................................................[Stats Function End].......................................................

async def get_total_users():
    try:
        count = await users_collection.count_documents({})
        return count
    except Exception as e:
        print(f"Error getting total users: {e}")
        return 0

async def get_premium_users_count():
    try:
        count = await users_collection.count_documents({"status": "PREMIUM"})
        return count
    except Exception as e:
        print(f"Error getting premium users count: {e}")
        return 0
#................................................[Stats Function End].......................................................
